﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AuthenticationService.Configurations;
using AuthenticationService.Models;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace AuthenticationService.JWT
{
    public class JWTAuthValidation : IJWTAuthValidation
    {
        private static JWTConfiguration jWTConfiguration;
        public JWTAuthValidation(IOptions<JWTConfiguration> jwtConfigOptions)
        {
            jWTConfiguration = jwtConfigOptions.Value;
        }

        public string GenerateToken(User user)
        {
            byte[] key = Encoding.ASCII.GetBytes(jWTConfiguration.SecretKey);
            JwtSecurityTokenHandler jwtSecurityTokenHandler = new JwtSecurityTokenHandler();
            SecurityTokenDescriptor securityTokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.NameIdentifier,user.UserId)
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                Issuer = jWTConfiguration.Issuer,
                Audience = jWTConfiguration.Audience,
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            JwtSecurityToken token = jwtSecurityTokenHandler.CreateJwtSecurityToken(securityTokenDescriptor);
            return jwtSecurityTokenHandler.WriteToken(token);
        }

        public Boolean ValidateToken(string token)
        {
            if(token.Length<7)
            {
                return false;
            }
            else
            {
                token = token.Substring(7);
            }
            SecurityToken securityToken;
            JwtSecurityTokenHandler jwtSecurityTokenHandler = new JwtSecurityTokenHandler();
            TokenValidationParameters validationParameters = new TokenValidationParameters();
            validationParameters.ValidateIssuerSigningKey = true;
            validationParameters.IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(jWTConfiguration.SecretKey));
            validationParameters.ValidateIssuer = true;
            validationParameters.ValidIssuer = jWTConfiguration.Issuer;
            validationParameters.ValidateAudience = true;
            validationParameters.ValidAudience = jWTConfiguration.Audience;
            validationParameters.ValidateLifetime = true;
            try
            {
                jwtSecurityTokenHandler.ValidateToken(token, validationParameters, out securityToken);
                return true;
            }
            catch( Exception)
            {
                return false;
            }
        }
        
    }
}
