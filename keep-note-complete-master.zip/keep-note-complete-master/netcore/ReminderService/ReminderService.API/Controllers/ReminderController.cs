﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ReminderService.API.Exceptions;
using ReminderService.API.Extensions;
using ReminderService.API.Models;
using ReminderService.API.Service;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ReminderService.API.Controllers
{
    [Route("api/[controller]")]
    [ExceptionLogger]
    //[TypeFilter(typeof(LoggingAspect))]
    [Authorize]
    public class ReminderController : Controller
    {
        private readonly IReminderService reminderService;

        public ReminderController(IReminderService _reminderService)
        {
            reminderService = _reminderService;
        }

        // GET: api/<controller>
        [HttpGet("{userId}")]
        public IActionResult Get(string userId)
        {
            return Ok(reminderService.GetAllReminders(userId));
        }

        // GET api/<controller>/5
        [HttpGet("{userId}/{noteId}/{reminderName}")]
        public IActionResult Get(string userId, int noteId, string reminderName)
        {
            return Ok(reminderService.GetReminderById(userId, noteId, reminderName));
        }

        // POST api/<controller>
        [HttpPost("{userId}")]
        public IActionResult Post(string userId,[FromBody]Reminder reminder)
        {
            if (ModelState.IsValid)
            {
                return Created("api/Reminder", reminderService.AddReminder(userId,reminder));
            }
            else
            {
                throw new ModelInvalidException(typeof(Reminder).Name);
            }
        }

        // PUT api/<controller>/5
        [HttpPut("{userId}/{noteId}/{reminderName}")]
        public IActionResult Put(string userId, int noteId, string reminderName, [FromBody]Reminder reminder)
        {
            if (ModelState.IsValid)
            {
                return Ok(reminderService.UpdateReminder(userId, noteId, reminderName, reminder));
            }
            else
            {
                throw new ModelInvalidException(typeof(Reminder).Name);
            }
        }

        // DELETE api/<controller>/5
        [HttpDelete("{userId}/{noteId}/{reminderName}")]
        public IActionResult Delete(string userId, int noteId, string reminderName)
        {
            return Ok(reminderService.DeleteReminder(userId, noteId, reminderName));
        }
    }
}
