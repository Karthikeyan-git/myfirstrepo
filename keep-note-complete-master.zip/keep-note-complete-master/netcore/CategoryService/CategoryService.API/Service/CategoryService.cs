﻿using System;
using System.Collections.Generic;
using System.Linq;
using CategoryService.API.Models;
using CategoryService.API.Repository;
using CategoryService.API.Exceptions;
using MongoDB.Driver;

namespace CategoryService.API.Service
{
    public class CategoryService : ICategoryService
    {
        private readonly ICategoryRepository categoryRepository;

        public CategoryService(ICategoryRepository _categoryRepository)
        {
            categoryRepository = _categoryRepository;
        }

        public CategoryUser CreateCategory(CategoryUser categoryUser)
        {
            if (categoryRepository.GetCategoryUserById(categoryUser.UserId) == null)
            {
                return categoryRepository.CreateCategory(categoryUser);
            }
            else
            {
                throw new CategoryNotCreatedException("This user has category already");
            }
        }

        public bool AddCategory(string userId, Category category)
        {
            CategoryUser catUser = categoryRepository.GetCategoryUserById(userId);
            if (catUser != null)
            {
                if(catUser.Categories != null && catUser.Categories.Count > 0)
                {
                    Category _category = catUser.Categories.FirstOrDefault(cat => cat.Name.ToUpper() == category.Name.ToUpper());
                    if (_category != null)
                    {
                        return categoryRepository.UpdateCategory(userId, category.Name, category);
                    }
                    else
                    {
                        return categoryRepository.AddCategory(userId, category);
                    }
                }
                return categoryRepository.AddCategory(userId, category);
            }
            else
            {
                CategoryUser cu = new CategoryUser();
                cu.UserId = userId;
                category.Id = 1;
                cu.Categories = new List<Category>();
                cu.Categories.Add(category);
                categoryRepository.CreateCategory(cu);
                return true;
            }
        }

        public bool UpdateCategory(string userId, string categoryName, Category category)
        {
            Category _cat = GetCategoryById(userId, categoryName);
            category.Id = _cat.Id;
            return categoryRepository.UpdateCategory(userId, categoryName, category);
        }

        public bool DeleteCategory(string userId, string categoryName)
        {
            GetCategoryById(userId, categoryName);
            return categoryRepository.DeleteCategory(userId, categoryName);
        }

        public CategoryUser GetCategoryUserById(string userId)
        {
            CategoryUser categoryUser = categoryRepository.GetCategoryUserById(userId);
            if (categoryUser == null)
            {
                throw new CategoryNotFoundException("This user has no category");
            }
            else
            {
                return categoryUser;
            }
        }

        public List<Category> GetAllCategoriesByUserId(string userId)
        {
            List<Category> categories = GetCategoryUserById(userId).Categories;
            if (categories == null)
            {
                throw new CategoryNotFoundException("This user has no category");
            }
            else
            {
                return categories;
            }
        }

        public Category GetCategoryById(string userId,string categoryName)
        {
            Category _category = GetAllCategoriesByUserId(userId).FirstOrDefault(cat => cat.Name.ToUpper() == categoryName.ToUpper());
            if (_category == null)
            {
                throw new CategoryNotFoundException("This category id not found");
            }
            else
            {
                return _category;
            }
        }
    }
}
