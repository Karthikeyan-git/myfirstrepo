import { Component, OnInit } from '@angular/core';
import {NotesService} from '../services/notes.service';
import {HttpClient} from '@angular/common/http';
import { Note } from '../note';
import { ActivatedRoute} from '@angular/router/';
import { RouterService } from '../services/router.service';
import { CatRem } from '../catRem';
import { Category } from '../category';

@Component({
  selector: 'app-note-view',
  templateUrl: './note-view.component.html',
  styleUrls: ['./note-view.component.css']
})
export class NoteViewComponent implements OnInit {
  public notes: Array<Note>;
  subHeading: string;
  remainder: boolean = false;
  isViewReady: boolean = false;
  constructor(private notesService: NotesService, private httpClient: HttpClient, 
    private activatedRoute: ActivatedRoute, private routerService: RouterService) {

  }

  ngOnInit() {  
    this.activatedRoute.params.subscribe(
      next => {
        if(next != null && next.catRem != null) {
          let catRem = localStorage.getItem('catRem');
          if(catRem!=null) {
            let cr: CatRem = JSON.parse(catRem);
            if(cr.isCat){
              this.subHeading = `Notes with Category : ${cr.category.name}`;
              this.getNotesByCategory(cr.category);
            } else {
              this.subHeading = 'Notes with Reminder';
              this.getNotesWithReminders();
            }
          } else {
            this.subHeading=undefined;
            this.getNotes();
          }
        } else {
          this.subHeading=undefined;
          this.getNotes();
        }
        this.isViewReady = true;
      }, err => {
        this.subHeading=undefined;
        this.getNotes();
        this.isViewReady = true;
      }
    );    
  }

  

  getNotesWithReminders(){
    this.getNotes();
    this.notes = this.notes.filter(nt => nt.reminders != null && nt.reminders.length > 0);
    // this.notesService.getNotesWithRemainder().subscribe(
    //   next => {
    //     this.notes = next;
    //   },
    //   err => {
    //     if(err instanceof ErrorEvent){
    //       if(err.error.statuscode === '401'){
    //         this.routerService.routeToLogin();
    //       }
    //     }
    //   }
    // );
  }

  getNotesByCategory(category : Category){
    this.getNotes();
    this.notes = this.notes.filter(nt => {
      if(nt.categories != null && nt.categories.some(cat => cat.name.toUpperCase() == category.name.toUpperCase())){
        return nt;
      }
    });
    console.log(this.notes);
    // this.notesService.getNotesByCategory(category).subscribe(
    //   next => {
    //      this.notes = next;
    //     },
    //   err => {
    //     if(err instanceof ErrorEvent){
    //       if(err.error.statuscode === '401'){
    //         this.routerService.routeToLogin();
    //       }
    //     }
    //   }
    // );
  }


  getNotes() {
    this.notesService.getNotes().subscribe(
      next => {
        console.log(`noteview getNotes : ${next}`);
         this.notes = next;
        },
      err => {
        if(err instanceof ErrorEvent){
          if(err.error.statuscode === '401'){
            this.routerService.routeToLogin();
          }
        }
      }
    );
  }
}
