export class AddEditModel{
    userId: string;
    noteId: Number;
    crId: Number;
    isNew: boolean;

    constructor(userId: string, noteId: Number, crId: Number, isNew: boolean){
        this.userId = userId;
        this.noteId = noteId;
        this.crId = crId;
        this.isNew = isNew;
    }
}