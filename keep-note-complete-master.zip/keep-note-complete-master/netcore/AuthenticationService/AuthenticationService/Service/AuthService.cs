﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Models;
using AuthenticationService.Repository;
using AuthenticationService.Exceptions;

namespace AuthenticationService.Service
{
    public class AuthService : IAuthService
    {
        private readonly IAuthRepository repository;
        
        public AuthService(IAuthRepository _repository)
        {
            this.repository = _repository;
        }
        public User LoginUser(string userId, string password)
        {
            User user = repository.LoginUser(userId, password);
            if (user == null)
            {
                throw new UserNotFoundException($"User with this id {userId} and password {password} does not exist");
            }
            else
            {
                return user;
            }
        }

        public bool RegisterUser(User user)
        {
            User _user = repository.FindUserById(user.UserId);
            if (_user == null)
            {
                bool r= repository.RegisterUser(user);
                if (r)
                {
                    return r;
                }
                else
                {
                    throw new UserNotCreatedException($"User with this id {user.UserId} already exists");
                }
            }
            else
            {
                throw new UserNotCreatedException($"User with this id {user.UserId} already exists");
            }
        }
    }
}
