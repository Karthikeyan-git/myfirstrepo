import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { CatRem } from '../catRem';
import { Category } from '../category';

@Injectable()
export class RouterService {

  recentURL: string;

  constructor(private router: Router) {
    this.recentURL = 'dashboard';
  }

  routeToDashboard() {
    if (localStorage.getItem('catRem') !=null ) {
      localStorage.removeItem('catRem');
    }    
    //let urlSec: Number = new Date().getSeconds();
    //this.recentURL = 'dashboard/' + urlSec;
    this.recentURL = 'dashboard';
    this.router.onSameUrlNavigation='reload';
    this.router.navigate(['dashboard']);
  }

  routeToLogin() {
    this.recentURL = 'login';
    this.router.navigate(['login']);
  }

  routeToRegister() {
    this.recentURL = 'register';
    this.router.navigate(['register']);
  }

  routeToEditNoteView(noteId) {
     this.router.navigate([`dashboard/edit/${noteId}`]);
  }

  routeBack() {
    this.router.onSameUrlNavigation='reload';
    this.router.navigate([this.recentURL]);
  }

  routeToNoteView() {
    let urlSec = new Date().getSeconds();
    this.recentURL = 'dashboard/view/noteview/' + urlSec;
    this.router.onSameUrlNavigation='reload';
    this.router.navigate([this.recentURL]);
  }

  routeToListView() {
    let urlSec = new Date().getSeconds();
    this.recentURL = 'dashboard/view/listview' + urlSec;
    this.router.onSameUrlNavigation='reload';
    this.router.navigate([this.recentURL]);
  }


  routeToViewCat(category : Category) {
    let catRem: CatRem = new CatRem(true,category);
    localStorage.setItem('catRem',JSON.stringify(catRem));
    if(this.router.url.indexOf('listview') < 0) {
      this.routeToNoteView();
    } else {
      this.routeToListView();
    }
  }

  routeToViewReminder(){
    if (localStorage.getItem('catRem') !=null ) {
      localStorage.removeItem('catRem');
    }
    let urlSec: Number = new Date().getSeconds();
    this.recentURL='dashboard/view/reminderview/' + urlSec;
    console.log(this.recentURL);
    this.router.navigate([this.recentURL]);
  }

  toggleToNoteView() {
    this.recentURL=this.router.url.replace('listview','noteview');
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate([this.recentURL]);
  }

  toggleToListView() {
    this.recentURL = this.router.url.replace('noteview','listview');
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate([this.recentURL]);
  }
  

  // routeToNoteView(category: string){
  //   this.recentURL = 'dashboard/view/'+category+'/noteview';
  //   this.router.navigate([this.recentURL]);
  // }

  // routeToListView(category: string){
  //   this.recentURL = 'dashboard/view/'+category+'/listview';
  //   this.router.navigate([this.recentURL]);
  // }

  // routeToNoteView(withReminder: boolean){
  //   this.recentURL = 'dashboard/view/'+withReminder+'/noteview';
  //   this.router.navigate([this.recentURL]);
  // }

  // routeToListView(withReminder: boolean) {
  //   this.recentURL = 'dashboard/view/'+withReminder+'/listview';
  //   this.router.navigate([this.recentURL]);
  // }
}
