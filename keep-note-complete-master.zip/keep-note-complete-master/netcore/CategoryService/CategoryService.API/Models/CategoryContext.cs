﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CategoryService.API.Configurations;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace CategoryService.API.Models
{
    public class CategoryContext : ICategoryContext
    {
        private readonly MongoDBConfiguration mongoDB;

        public IMongoCollection<CategoryUser> CategoryUsers { get; }

        public CategoryContext(IConfiguration configuration)
        {
            mongoDB = new MongoDBConfiguration { ConnectionString = configuration.GetSection("MongoDB").GetValue<string>("ConnectionString"), Database = configuration.GetSection("MongoDB").GetValue<String>("Database") };
            MongoClient mongoClient = new MongoClient(mongoDB.ConnectionString);
            CategoryUsers = mongoClient.GetDatabase(mongoDB.Database).GetCollection<CategoryUser>("CategoryUser");
        }

    }
}
