import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { tap } from 'rxjs/operators';
import { Category } from '../category';

@Injectable()
export class CategoryService {

  categoriesURL: string;
  categories = new Array<Category>();
  categorySubject = new BehaviorSubject<Array<Category>>(this.categories);
  categoryDeleteURL: string;
  categoryAddURL: string;
  categoryEditURL: string;
  categoriesOfNote: string;
  categoriesDistinct: string;


  constructor(private httpClient: HttpClient, private authenticationService: AuthenticationService) {
    this.categoriesURL = 'http://localhost:8001/api/notes/getAllCategories/'+this.authenticationService.getUserId();
    this.categoriesOfNote = 'http://localhost:8001/api/notes/getAllCategories/'+this.authenticationService.getUserId();
    this.categoryDeleteURL = 'http://localhost:8001/api/notes/deleteCategory/'+this.authenticationService.getUserId();
    this.categoryAddURL = 'http://localhost:8001/api/notes/addCategory/'+this.authenticationService.getUserId();
    this.categoryEditURL = 'http://localhost:8001/api/notes/editCategory/'+this.authenticationService.getUserId();
    this.categoriesDistinct = 'http://localhost:8001/api/notes/getDistinctCategories/'+this.authenticationService.getUserId();
    //this.fetchCategoriesFromServer();
  }

  fetchCategoriesFromServer() {
    this.httpClient.get<Category[]>(this.categoriesURL, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).subscribe(
      next => {
        this.categories = next;
        this.categorySubject.next(this.categories);
      },
      err => {
        console.log(err);
        this.categories = new Array<Category>();
        this.categorySubject.next(this.categories);
      }
    );
  }

  setCategories(cats: Array<Category>){
    this.categories = cats;
    this.categorySubject = new BehaviorSubject<Array<Category>>(this.categories);
  }

  getCategories(): BehaviorSubject<Array<Category>> {
    return this.categorySubject;
  }

  // addCategory(category: Category){
  //     this.categories.push(category);
  //     this.categorySubject.next(this.categories);
  // }

  // editCategory(category: Category){
  //     let catInArr: Category;
  //     catInArr = this.getCategoryById(category.id);
  //     Object.assign(catInArr, category);
  //     this.categorySubject.next(this.categories);
  // } 

  getcategoriesbynoteid(noteId: Number){
    const catByNote = this.categoriesOfNote.concat('/',noteId.toString());
    this.httpClient.get<Category[]>(catByNote,
    {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).subscribe(
      next => {
        this.categories = next;
        this.categorySubject.next(this.categories);
      },
      err => {
        console.log(err);
        this.categories = new Array<Category>();
        this.categorySubject.next(this.categories);
      }
    )
  }

  getDistinctCategories() : Observable<Category[]>{
    console.log(this.categoriesDistinct);
    return this.httpClient.get<Category[]>(this.categoriesDistinct, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    });
  }

  getDistinctCategoriesOfNote(noteId : Number) : Observable<Category[]>{
    console.log(this.categoriesDistinct);
    return this.httpClient.get<Category[]>(this.categoriesDistinct + '/' + noteId, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    });
  }
  
  async deleteCategory(noteId: Number,categoryID: Number) : Promise<Boolean>{
    const deleteURL = this.categoryDeleteURL.concat("/",noteId.toString(),"/",categoryID.toString());
    const result = await this.httpClient.delete(deleteURL,{
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).toPromise();
    const resultPromise: Promise<Boolean> = new Promise((res,rej) => {
      if(result == true){
        this.categories.splice(this.categories.findIndex(cat=>cat.id === categoryID),1);
        this.categorySubject.next(this.categories);
        res(true);
      } else {
        rej(false);
      } 
    });
    return resultPromise;       
  }

  async addCategory(noteID: Number,category: Category): Promise<Boolean> {
    console.log(noteID + ' : ' + JSON.stringify(category));
    const addURL=this.categoryAddURL.concat('/',noteID.toString());
    console.log(addURL);
    const addedCategory = await this.httpClient.post<Category>(addURL, category,
    {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).toPromise();
    console.log(addedCategory);
    const addedResult = new Promise<Boolean>((res,rej) => {
      if(addedCategory && addedCategory != null){
        console.log(addedCategory);
        this.categories.push(addedCategory);
        this.categorySubject.next(this.categories);
        res(true);
      } else {
        rej(false);
      }
    });
    return addedResult;
  }

  addCategoryToList(categoryObj: Category){
    this.categories.push(categoryObj);
    this.categorySubject.next(this.categories);
  }

  addEditCategoryToList(categoryObj: Category){
    const catFromArr: Category = this.categories.find(cat=>cat.name.toUpperCase() == categoryObj.name.toUpperCase());
    Object.assign(catFromArr,categoryObj);
    this.categorySubject.next(this.categories);
  }

  deleteCategoryFromList(categoryObj: Category){
    this.categories.splice(this.categories.findIndex(cat => cat.name == categoryObj.name),1);
    this.categorySubject.next(this.categories);
  }

  async editCategory(noteID:Number,categoryID: Number,category: Category): Promise<Boolean> {
    const putURL = this.categoryEditURL.concat('/',noteID.toString(),'/',categoryID.toString());
    const updatedCategory = await this.httpClient.put<Category>(putURL, category,
    {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).toPromise();
    const result = new Promise<Boolean>((res,rej)=>{
      if(updatedCategory &&  updatedCategory!=null) {
        const arrCategory: Category = this.getCategoryById(categoryID);
        Object.assign(arrCategory, updatedCategory);
        this.categorySubject.next(this.categories);
        res(true);
      } else {
        rej(false);
      }
    });
    return result;
  }

   getCategoryById(categoryId): Category {
     const catID: Number = categoryId;
     return this.categories.find(c => c.id === catID);
   }
}
