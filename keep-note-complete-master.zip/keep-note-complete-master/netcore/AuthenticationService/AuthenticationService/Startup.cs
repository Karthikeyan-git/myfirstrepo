﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Configurations;
using AuthenticationService.Filters;
using AuthenticationService.JWT;
using AuthenticationService.Logs;
using AuthenticationService.Models;
using AuthenticationService.Repository;
using AuthenticationService.Service;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Swashbuckle.AspNetCore.Swagger;

namespace AuthenticationService
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {            
            //services.AddDbContext<AuthenticationContext>(options => options.UseSqlServer(Configuration.GetConnectionString("sqlserver")));
            //var dbContextOptions = new DbContextOptionsBuilder();
            //dbContextOptions.UseSqlServer(Configuration.GetConnectionString("sqlserver"));
            //AuthenticationContext authenticationContext = new AuthenticationContext(dbContextOptions.Options);
            //authenticationContext.Database.EnsureCreated();
            services.AddOptions();            
            services.Configure<JWTConfiguration>(options => Configuration.GetSection("JWTConfiguration").Bind(options));
            services.AddScoped<IJWTAuthValidation,JWTAuthValidation>();
            services.Configure<FileLoggerConfiguration>(options => Configuration.GetSection("FileLoggerConfiguration").Bind(options));
            services.AddScoped<ILogger, FileLogger>();
            services.AddScoped<IAuthenticationMongoContext, AuthenticationMongoContext>();
            services.AddScoped<IAuthRepository, AuthMongoRepository>();
            services.AddScoped<IAuthService, AuthService>();
            services.AddSwaggerGen(s => s.SwaggerDoc("Authenticate", new Info { Title = "Authenticate Service", Version = "V1" }));
            services.AddCors(options =>
            {
                options.AddPolicy("KeepNotesAuthPolicy", builder =>
                {
                    builder.AllowAnyOrigin();
                    builder.AllowAnyHeader();
                    builder.AllowAnyMethod();
                });
            });
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            //services.AddHttpsRedirection(options => options.HttpsPort = 443);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }



            app.UseCors("KeepNotesAuthPolicy");

            //app.UseHttpsRedirection();

            app.UseSwagger();
            app.UseSwaggerUI(s => s.SwaggerEndpoint("/swagger/Authenticate/swagger.json", "Authenticate Service"));

            app.UseMvc(defaultRoutes => defaultRoutes.MapRoute(
                name: "default",
                template: "api/{controller}",
                defaults: new { controller = "Auth" }));
        }
    }
}
