﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Models;
using MongoDB.Driver;

namespace AuthenticationService.Repository
{
    public class AuthMongoRepository : IAuthRepository
    {
        readonly IMongoCollection<User> users;
        public AuthMongoRepository(IAuthenticationMongoContext authenticationMongoContext)
        {
            users = authenticationMongoContext.users;
        }

        public User FindUserById(string userId)
        {
            return users.Find<User>(u => u.UserId == userId).FirstOrDefault();
        }

        public User LoginUser(string userId, string password)
        {
            return users.Find<User>(u => u.UserId == userId && u.Password == password).FirstOrDefault();
        }

        public bool RegisterUser(User user)
        {
            users.InsertOne(user);
            return true;
        }
    }
}
