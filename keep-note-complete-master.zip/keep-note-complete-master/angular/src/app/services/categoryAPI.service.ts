import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { Category } from '../category';

@Injectable()
export class CategoryAPIService{
    private categoryAPIURL: string;

    constructor(private authenticationService:AuthenticationService, private httpClient: HttpClient){
        this.categoryAPIURL= 'http://localhost:8003/api/category/' + this.authenticationService.getUserId();
    }

    async addCategory(category: Category) : Promise<boolean>{
        const addResult = await this.httpClient.post<boolean>(this.categoryAPIURL,category,{
            headers: new HttpHeaders().set('Authorization',`Bearer ${this.authenticationService.getBearerToken()}`)
        }).toPromise();
        console.log(addResult);
        const result: Promise<boolean> = new Promise<boolean>((res,rej) => {
            if(addResult && addResult!=null && addResult === true){
                res(true);
            } else {
                rej(false);
            }
        });
        return result;
    }

    async editCategory(category: Category) : Promise<boolean>{
        const editResult = await this.httpClient.put<boolean>(this.categoryAPIURL + '/' + category.name,category,{
            headers: new HttpHeaders().set('Authorization',`Bearer ${this.authenticationService.getBearerToken()}`)
        }).toPromise();
        console.log(editResult);
        const result: Promise<boolean> = new Promise<boolean>((res,rej) => {
            if(editResult && editResult!=null && editResult === true){
                res(true);
            } else {
                rej(false);
            }
        });
        return result;
    }

    async deleteCategory(category: Category) : Promise<boolean>{
        const deleteResult = await this.httpClient.delete<boolean>(this.categoryAPIURL + '/' + category.name,{
            headers: new HttpHeaders().set('Authorization',`Bearer ${this.authenticationService.getBearerToken()}`)
        }).toPromise();
        console.log(deleteResult);
        const result: Promise<boolean> = new Promise<boolean>((res,rej) => {
            if(deleteResult && deleteResult!=null && deleteResult === true){
                res(true);
            } else {
                rej(false);
            }
        });
        return result;
    }
}