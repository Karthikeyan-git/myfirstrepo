﻿using System;
using System.Collections.Generic;
using System.Linq;
using MongoDB.Driver;
using NoteService.API.Models;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;

namespace NoteService.API.Repository
{
    public class NoteRepository : INoteRepository
    {
        private readonly INoteContext noteContext;

        public NoteRepository(INoteContext _noteContext)
        {
            noteContext = _noteContext;
        }

        public Note CreateNote(NoteUser noteUser)
        {
            Note nt = noteUser.Notes[0];
            if (nt.Categories != null)
            {
                long ctId = 1;
                foreach (Category ct in nt.Categories)
                {
                    ct.Id = ctId++;
                }
            }
            if (nt.Reminders != null)
            {
                long rmId = 1;
                foreach (Reminder rm in nt.Reminders)
                {
                    rm.Id = rmId++;
                }
            }
            nt.Id = 1;
            noteContext.Notes.InsertOne(noteUser);
            return GetNoteById(nt.Id, noteUser.UserId);
        }

        public Note GetNoteById(long noteId, string userId)
        {
            return noteContext.Notes.Find(nu => nu.UserId == userId).FirstOrDefault().Notes.FirstOrDefault(nt => nt.Id == noteId);
        }

        public bool DeleteNote(string userId, int noteId)
        {
            var pullOperatorDefinition = Builders<NoteUser>.Update.PullFilter(nu => nu.Notes, Builders<Note>.Filter.Eq(n => n.Id, noteId));
            UpdateResult ur = noteContext.Notes.UpdateOne<NoteUser>(nu => nu.UserId == userId, pullOperatorDefinition);
            return ur.IsAcknowledged && ur.ModifiedCount > 0;
        }

        public List<Note> FindByUserId(string userId)
        {
            return noteContext.Notes.Find<NoteUser>(nu => nu.UserId == userId).FirstOrDefault().Notes;
        }

        public Note UpdateNote(int noteId, string userId, Note note)
        {
            if (note.Categories != null && note.Categories.Count > 0)
            {
                long ctId = 1;
                foreach (Category ct in note.Categories)
                {
                    ct.Id = ctId++;
                }
            }
            if (note.Reminders != null && note.Reminders.Count > 0)
            {
                long rmId = 1;
                foreach (Reminder rm in note.Reminders)
                {
                    rm.Id = rmId++;
                }
            }
            var updateDefinition = Builders<NoteUser>.Update.Set<Note>("Notes.$", note);
            noteContext.Notes.FindOneAndUpdate(nu => nu.UserId == userId && nu.Notes.Any(n => n.Id == noteId), updateDefinition);
            return GetNoteById(noteId, userId);
        }

        public NoteUser GetNoteUserById(string userId)
        {
            return noteContext.Notes.Find<NoteUser>(note => note.UserId == userId).FirstOrDefault();
        }

        public Note AddNote(string userId, Note note)
        {

            NoteUser ntus = noteContext.Notes.Find(ntu => ntu.UserId == userId).FirstOrDefault();
            if (ntus.Notes != null && ntus.Notes.Count > 0)
            {
                long maxId = ntus.Notes.Max<Note>(nt => nt.Id);
                note.Id = maxId + 1;
            } else
            {
                note.Id = 1;
            }
            if (note.Categories != null && note.Categories.Count > 0)
            {
                long ctId = 1;
                foreach (Category ct in note.Categories)
                {
                    ct.Id = ctId++;
                }
            }
            if (note.Reminders != null && note.Reminders.Count > 0)
            {
                long rmId = 1;
                foreach (Reminder rm in note.Reminders)
                {
                    rm.Id = rmId++;
                }
            }
            var pushOperatorDefinition = Builders<NoteUser>.Update.Push<Note>(nu => nu.Notes, note);
            UpdateResult ur = noteContext.Notes.UpdateOne<NoteUser>(nu => nu.UserId == userId, pushOperatorDefinition);
            return GetNoteById(note.Id, userId);
        }

        public List<Note> GetNotes(string userId, int categoryId)
        {
            return noteContext.Notes.Find(nu => nu.UserId == userId).FirstOrDefault().Notes.Where(note => note.Categories.Any(c=>c.Id == categoryId)).ToList();
        }

        public bool DeleteCategory(string userId, int noteId, int categoryId)
        {
            //var pullOperatorDefinition = Builders<NoteUser>.Update.PullFilter(nu => nu.Notes.First(nt => nt.Id == noteId).Categories, Builders<Category>.Filter.Eq(cat => cat.Id,categoryId));
            //UpdateResult ur = noteContext.Notes.UpdateOne<NoteUser>(nu => nu.UserId == userId, pullOperatorDefinition);
            //return ur.IsAcknowledged && ur.ModifiedCount == 1; 
            Note note = this.GetNoteById(noteId, userId);
            if (note.Categories != null && note.Categories.Count > 0)
            {
                note.Categories.Remove(note.Categories.FirstOrDefault(cat => cat.Id == categoryId));
                this.UpdateNote(noteId, userId, note);
                return true;
            }
            return false;
        }

        public Category AddCategory(string userId, int noteId, Category category)
        {
            Note note = this.GetNoteById(noteId, userId);
            if(note.Categories != null && note.Categories.Count > 0)
            {
                category.Id = note.Categories.Max(cat => cat.Id) + 1;
            } else
            {
                note.Categories = new List<Category>();
                category.Id = 1;
            }
            note.Categories.Add(category);
            return UpdateNote(noteId, userId, note).Categories.FirstOrDefault(ct=>ct.Id == category.Id);
        }

        public Category EditCategory(string userId, int noteId, int categoryId, Category category)
        {
            Note note = this.GetNoteById(noteId, userId);
            if (note.Categories != null && note.Categories.Count > 0)
            {
                int i = note.Categories.FindIndex(ct => ct.Id == categoryId);
                note.Categories.RemoveAt(i);
                note.Categories.Insert(i, category);
                return UpdateNote(noteId, userId, note).Categories.FirstOrDefault(ct => ct.Id == category.Id);
            }
            else
            {
                return null;
            }
        }

        public bool DeleteReminder(string userId, int noteId, int reminderId)
        {
            Note note = this.GetNoteById(noteId, userId);
            if (note.Reminders != null && note.Reminders.Count > 0)
            {
                note.Reminders.Remove(note.Reminders.FirstOrDefault(rem => rem.Id == reminderId));
                this.UpdateNote(noteId, userId, note);
                return true;
            }
            return false;
        }

        public Reminder AddReminder(string userId, int noteId, Reminder reminder)
        {
            Note note = this.GetNoteById(noteId, userId);
            if (note.Reminders != null && note.Reminders.Count > 0)
            {
                reminder.Id = note.Reminders.Max(rem => rem.Id) + 1;                             
            }
            else
            {
                note.Reminders = new List<Reminder>();
                reminder.Id = 1;
            }
            note.Reminders.Add(reminder);
            return UpdateNote(noteId, userId, note).Reminders.FirstOrDefault(rem => rem.Id == reminder.Id);
        }

        public Reminder EditReminder(string userId, int noteId, int reminderId, Reminder reminder)
        {
            Note note = this.GetNoteById(noteId, userId);
            if (note.Reminders != null && note.Reminders.Count > 0)
            {
                int i = note.Reminders.FindIndex(rem => rem.Id == reminderId);
                note.Reminders.RemoveAt(i);
                note.Reminders.Insert(i, reminder);
                return UpdateNote(noteId, userId, note).Reminders.FirstOrDefault(rem => rem.Id == reminder.Id);
            }
            else
            {
                return null;
            }            
        }
    }
}
