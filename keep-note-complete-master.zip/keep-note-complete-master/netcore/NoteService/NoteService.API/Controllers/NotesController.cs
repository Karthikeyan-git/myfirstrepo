﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NoteService.API.Extensions;
using NoteService.API.Models;
using NoteService.API.Service;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NoteService.API.Controllers
{
    [Route("api/[controller]")]
    [ExceptionLogger]
    //[TypeFilter(typeof(LoggingAspect))]
    [Authorize]
    public class NotesController : Controller
    {

        private INoteService noteService;

        public NotesController(INoteService _noteService)
        {
            noteService = _noteService;
        }

        //// GET: api/<controller>
        //[HttpGet]
        //public IActionResult Get()
        //{
        //    string userId = "";
        //    return Ok(noteService.GetAllNotes(userId));
        //}

        // GET api/<controller>/5
        [HttpGet("{userId}")]
        public IActionResult Get(string userId)
        {
            return Ok(noteService.GetAllNotes(userId));
        }

        // POST api/<controller>
        [HttpPost("{userId}")]
        public IActionResult Post(string userId,[FromBody]Note note)
        {
            return Ok(noteService.AddNote(userId, note));
        }

        // PUT api/<controller>/5
        [HttpPut("{userid}/{noteid}")]
        public IActionResult Put(string userId, int noteId, [FromBody]Note note)
        {
            return Ok(noteService.UpdateNote(noteId, userId, note));
        }

        // DELETE api/<controller>/5
        [HttpDelete("{userid}/{noteid}")]
        public IActionResult Delete(string userId,int noteId)
        {
            return Ok(noteService.DeleteNote(userId, noteId));
        }

        [HttpPost("getNotesByCategory/{userId}")]
        public IActionResult GetNotesByCategoryId(string userId,[FromBody]Category category)
        {
            Console.WriteLine(category.Name);
            return Ok(noteService.GetNotes(userId,category.Name));
        }

        [HttpGet("{userId}/{withReminder}")]
        public IActionResult GetNotesWithReminders(string userId,bool withReminder)
        {
            return Ok(noteService.GetAllNotes(userId).Where(note => note.Reminders != null && note.Reminders.Count > 0));
        }

        //[HttpGet("getAllCategories/{userId}")]
        //public IActionResult GetAllCategories(string userId)
        //{
        //    return Ok(noteService.GetAllCategories(userId));
        //}

        //[HttpGet("getAllCategories/{userId}/{noteId}")]
        //public IActionResult GetAllCategories(string userId, int noteId)
        //{
        //    return Ok(noteService.GetAllCategories(userId, noteId));
        //}

        [HttpGet("getDistinctCategories/{userId}")]
        public IActionResult GetDistinctCategories(string userId)
        {
            return Ok(noteService.GetDistinctCategories(userId));
        }

        [HttpGet("getDistinctCategories/{userId}/{noteId}")]
        public IActionResult GetDistinctCategories(string userId, int noteId)
        {
            return Ok(noteService.GetDistinctCategories(userId, noteId));
        }


        [HttpDelete("deleteCategory/{userId}/{noteId}/{categoryId}")]
        public IActionResult DeleteCatory(string userId, int noteId, int categoryId)
        {
            return Ok(noteService.DeleteCategory(userId, noteId, categoryId));
        }

        [HttpPost("addCategory/{userId}/{noteId}")]
        public IActionResult AddCategory(string userId, int noteId,[FromBody]Category category)
        {
            Console.WriteLine(userId + " : " + noteId + " : " + category.Id);
            return Ok(noteService.AddCategory(userId, noteId, category));
        }

        [HttpPut("editCategory/{userId}/{noteId}/{categoryId}")]
        public IActionResult EditCategory(string userId, int noteId, int categoryId, [FromBody]Category category)
        {
            Console.WriteLine(userId + " : " + noteId + " : " + category.Id);
            return Ok(noteService.EditCategory(userId, noteId, categoryId, category));
        }

        [HttpDelete("deleteReminder/{userId}/{noteId}/{reminderId}")]
        public IActionResult DeleteReminder(string userId, int noteId, int reminderId)
        {
            return Ok(noteService.DeleteReminder(userId, noteId, reminderId));
        }

        [HttpPost("addReminder/{userId}/{noteId}")]
        public IActionResult AddReminder(string userId, int noteId, [FromBody]Reminder reminder)
        {
            Console.WriteLine(userId + " : " + noteId + " : " + reminder.Id);
            return Ok(noteService.AddReminder(userId, noteId, reminder));
        }

        [HttpPut("editReminder/{userId}/{noteId}/{reminderId}")]
        public IActionResult EditReminder(string userId, int noteId, int reminderId, [FromBody]Reminder reminder)
        {
            Console.WriteLine(userId + " : " + noteId + " : " + reminder.Id);
            return Ok(noteService.EditReminder(userId, noteId, reminderId, reminder));
        }
    }
}
