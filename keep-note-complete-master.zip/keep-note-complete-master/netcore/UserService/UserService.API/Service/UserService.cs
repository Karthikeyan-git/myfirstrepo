﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserService.API.Exceptions;
using UserService.API.Models;
using UserService.API.Repository;

namespace UserService.API.Service
{
    public class UserService : IUserService
    {
        private IUserRepository userRepository;

        public UserService(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public bool DeleteUser(string userId)
        {
            GetUserById(userId);
            return userRepository.DeleteUser(userId);
        }

        public User GetUserById(string userId)
        {
            User _user = userRepository.GetUserById(userId);
            if (_user == null)
            {
                throw new UserNotFoundException("This user id does not exist");
            }
            return userRepository.GetUserById(userId);
        }

        public User RegisterUser(User user)
        {
            User _user = userRepository.GetUserById(user.UserId);
            if (_user != null)
            {
                throw new UserNotCreatedException("This user id already exists");
            }
            return userRepository.RegisterUser(user);
        }

        public bool UpdateUser(string userId, User user)
        {
            GetUserById(userId);
            return userRepository.UpdateUser(userId, user);
        }
    }
}
