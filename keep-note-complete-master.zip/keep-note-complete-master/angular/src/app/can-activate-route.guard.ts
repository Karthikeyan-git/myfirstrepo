import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from './services/authentication.service';
import { RouterService } from './services/router.service';

@Injectable()
export class CanActivateRouteGuard implements CanActivate {

  constructor(private authenticationService: AuthenticationService, private routerService: RouterService) {}

  async canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Promise<boolean> {
      let authResult = false;
      await this.authenticationService.isUserAuthenticated(this.authenticationService.getBearerToken()).then(res => {
        authResult = res;
      }).catch(err => {
        authResult = false;
      });
      return new Promise<boolean>((res, rej) => {
        if (authResult) {
          res(true);
        } else {
          rej(false);
          this.routerService.routeToLogin();
        }
      });
  }
}
