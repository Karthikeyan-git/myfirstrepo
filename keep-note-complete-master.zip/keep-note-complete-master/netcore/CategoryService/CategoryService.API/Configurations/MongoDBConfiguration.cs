﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CategoryService.API.Configurations
{
    public class MongoDBConfiguration
    {
        public String ConnectionString { get; set; }
 
        public String Database { get; set; }
    }
}
