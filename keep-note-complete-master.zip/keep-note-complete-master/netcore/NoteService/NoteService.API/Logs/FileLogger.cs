﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NoteService.API.Logs
{
    public class FileLogger : ILogger
    {
        private FileLoggerConfiguration fileLoggerConfiguration;

        public FileLogger(IOptions<FileLoggerConfiguration> _fileLoggerConfiguration)
        {
            fileLoggerConfiguration = _fileLoggerConfiguration.Value;
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return fileLoggerConfiguration.LogLevel == logLevel;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            if (IsEnabled(logLevel))
            {
                FileInfo fileInfo = new FileInfo(Path.Combine(fileLoggerConfiguration.LogFileDir,fileLoggerConfiguration.LogFileName));
                FileStream fileStream;
                if (fileInfo.Exists && fileInfo.Length >= fileLoggerConfiguration.MaxFileSizeInMB * 1024 * 1024)
                {
                    string bkpFileName = Path.GetFileNameWithoutExtension(fileLoggerConfiguration.LogFileName);
                    bkpFileName += DateTime.Now.ToString("YYYY-MM-DD-hh-mm-ssss");
                    bkpFileName = Path.GetExtension(fileLoggerConfiguration.LogFileName);
                    File.Move(Path.Combine(fileLoggerConfiguration.LogFileDir, fileLoggerConfiguration.LogFileName), Path.Combine(fileLoggerConfiguration.LogFileDir, bkpFileName));
                    fileStream = fileInfo.Open(FileMode.Create);
                }
                else
                {
                    fileStream = fileInfo.Open(FileMode.Append);
                }
                using (StreamWriter streamWriter = new StreamWriter(fileStream))
                {
                    streamWriter.WriteLine($"{logLevel} : {formatter(state, exception)}");
                }

            }
            else
            {
                return;
            }
        }
    }
}
