﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NoteService.API.Models;

namespace NoteService.API.Repository
{
    public interface INoteRepository
    {
        Note CreateNote(NoteUser noteUser);
        bool DeleteNote(string userId, int noteId);
        Note UpdateNote(int noteId, string userId, Note note);
        List<Note> FindByUserId(string userId);
        NoteUser GetNoteUserById(string userId);
        Note AddNote(string userId,Note note);
        List<Note> GetNotes(string userId,int categoryId);
        bool DeleteCategory(string userId, int noteId, int categoryId);
        Note GetNoteById(long noteId, string userId);
        Category AddCategory(string userId, int noteId, Category category);
        Category EditCategory(string userId, int noteId, int categoryId, Category category);

        bool DeleteReminder(string userId, int noteId, int reminderId);
        Reminder AddReminder(string userId, int noteId, Reminder reminder);
        Reminder EditReminder(string userId, int noteId, int reminderId, Reminder reminder);

    }
}
