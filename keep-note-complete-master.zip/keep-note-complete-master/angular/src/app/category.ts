export class Category{
    id: Number;
    name: string;
    description: string;
    createdBy: string;
    creationDate: string;

    constructor(){
        this.id = 0;
        this.name = '';
        this.description = '';
        this.createdBy = '';
        this.creationDate = new Date().toDateString();
    }
}