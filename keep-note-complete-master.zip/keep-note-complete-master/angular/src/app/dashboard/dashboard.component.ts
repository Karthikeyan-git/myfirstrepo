import { Component, OnInit } from '@angular/core';
import { NotesService } from '../services/notes.service';
import { AuthenticationService } from '../services/authentication.service';
import { CategoryService } from '../services/category.service';
import { RouterService } from '../services/router.service';
import { Category } from '../category';
import { UserInfo } from '../userInfo';
import { MatSidenavContent, MatSidenav, MatSidenavContainer, MatDivider, MatButton } from '@angular/material';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  
  isNoteView = true;
  isLogged: Boolean = false;
  categories:Array<Category>;
  userId: string;
  constructor(private notesService: NotesService, private authenticationService: AuthenticationService,
     private categoryService: CategoryService, private routerService: RouterService) {
  }

  ngOnInit() {
    this.isLogged = this.authenticationService.getIsAuthenticated();
    console.log(this.isLogged);
    this.userId = this.authenticationService.getUserId();
    this.notesService.fetchNotesFromServer();
    this.categoryService.getDistinctCategories().toPromise().then(
      next => this.categories = next,
      err => this.categories = new Array<Category>()
    );
  }

  editNoteOpen() {
    this.routerService.routeToEditNoteView(-1);
  }

  switchView() {
    if (this.isNoteView) {
      this.isNoteView = false;
      this.routerService.toggleToListView();
    } else {
      this.isNoteView = true;
      this.routerService.toggleToNoteView();
    }
  }

  routeToCatRemView(catRem){
    this.routerService.routeToViewCat(catRem);
  }

  routeToViewReminder(){
    this.routerService.routeToViewReminder();
  }

  routeToDashBoard(){
    this.routerService.routeToDashboard();
  }

  logout(){
    this.authenticationService.clearUserInfo();
    this.routerService.routeToLogin();
  }
}
