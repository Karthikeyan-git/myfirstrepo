﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserService.API.Extensions
{
    public class LoggingAspect : ActionFilterAttribute
    {
        private ILogger logger;
        private DateTime startTime;
        public LoggingAspect(ILogger logger) : base()
        {
            this.logger = logger;
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            base.OnActionExecuted(context);
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            startTime = DateTime.Now;
            logger.LogInformation("Starting Request URL : " + context.HttpContext.Request.Path);
            logger.LogInformation("Request Time : " + startTime.ToString("yyyy-MM-dd-hh-mm"));
            base.OnActionExecuting(context);
        }

        public override Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            return base.OnActionExecutionAsync(context, next);
        }

        public override void OnResultExecuted(ResultExecutedContext context)
        {
            HttpContext httpContext = context.HttpContext;
            TimeSpan timeSpan = DateTime.Now - startTime;
            logger.LogInformation("Response Time in seconds : " + timeSpan.Seconds);
            logger.LogInformation("Operation name : " + httpContext.Request.Method);
            logger.LogInformation("IP address of the requestor : " + httpContext.Request.HttpContext.Connection.RemoteIpAddress.ToString());
            logger.LogInformation("Exiting Request URL : " + context.HttpContext.Request.Path);
            base.OnResultExecuted(context);
        }

        public override void OnResultExecuting(ResultExecutingContext context)
        {
            base.OnResultExecuting(context);
        }

        public override Task OnResultExecutionAsync(ResultExecutingContext context, ResultExecutionDelegate next)
        {
            return base.OnResultExecutionAsync(context, next);
        }
    }
}
