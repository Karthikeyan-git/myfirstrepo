﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReminderService.API.Exceptions;
using ReminderService.API.Models;
using ReminderService.API.Repository;

namespace ReminderService.API.Service
{
    public class ReminderService : IReminderService
    {
        private readonly IReminderRepository reminderRepository;

        public ReminderService(IReminderRepository _reminderRepository)
        {
            reminderRepository = _reminderRepository;
        }

        public ReminderUser CreateReminder(ReminderUser reminderUser)
        {
            ReminderUser _reminderUser = reminderRepository.GetReminderUserById(reminderUser.UserId);
            if (_reminderUser != null)
            {
                throw new ReminderNotCreatedException("This reminder id already exists");
            }
            else
            {
                return reminderRepository.CreateReminder(reminderUser);
            }
        }

        public Reminder AddReminder(string userId, Reminder reminder)
        {
            ReminderUser _reminderUser = reminderRepository.GetReminderUserById(userId);
            if (_reminderUser != null)
            {
                if(reminderRepository.AddReminder(userId, reminder))
                {
                    return GetReminderById(userId, reminder.NoteId, reminder.Name);
                } 
                else
                {
                    throw new ReminderNotCreatedException("Reminder creation failed");
                }
            }
            else
            {
                ReminderUser ru = new ReminderUser();
                ru.UserId = userId;
                reminder.Id = 1;
                ru.Reminders = new List<Reminder>();
                ru.Reminders.Add(reminder);
                return CreateReminder(ru).Reminders.FirstOrDefault(rem => rem.Id == 1);
            }
        }

        public Reminder UpdateReminder(string userId, int noteId, string reminderName, Reminder reminder)
        {
            Reminder _rem = GetReminderById(userId, noteId, reminderName);
            reminder.Id = _rem.Id;
            if(reminderRepository.UpdateReminder(userId, noteId, reminderName, reminder))
            {
                return GetReminderById(userId, noteId, reminderName);
            }
            else
            {
                throw new ReminderNotCreatedException("Reminder updation failed");
            }
        }

        public bool DeleteReminder(string userId, int noteId, string reminderName)
        {
            GetReminderById(userId, noteId, reminderName);
            return reminderRepository.DeleteReminder(userId, noteId, reminderName);
        }

        public ReminderUser GetReminderUserById(string userId)
        {
            ReminderUser reminderUser = reminderRepository.GetReminderUserById(userId);
            if (reminderUser == null)
            {
                throw new ReminderNotFoundException("This user has no remnders");
            }
            else
            {
                return reminderUser;
            }
        }

        public List<Reminder> GetAllReminders(string userId)
        {
            ReminderUser ru = GetReminderUserById(userId);
            List<Reminder> reminders = ru.Reminders;
            if (reminders == null)
            {
                throw new ReminderNotFoundException("This user has no remnders");
            } else
            {
                return reminders;
            }        
        }

        public Reminder GetReminderById(string userId, int noteId, string reminderName)
        {
            Reminder reminder = GetAllReminders(userId).FirstOrDefault(r => r.NoteId == noteId && r.Name == reminderName);
            if (reminder != null)
            {
                return reminder;
            }
            else
            {
                throw new ReminderNotFoundException("This reminder id does not exist");
            }
        }
    }
}
