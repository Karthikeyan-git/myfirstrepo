import { Injectable, OnInit } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { RouterService } from './router.service';
import { tap } from 'rxjs/operators';
import { Reminder } from '../reminder';
import { NoteReminder } from '../noteReminder';

@Injectable()
export class ReminderService implements OnInit {
    
    private reminderAPIURL: string;
    public reminderSubject: BehaviorSubject<Array<Reminder>>;
    public reminders: Array<Reminder>;

    constructor(private authenticationService: AuthenticationService, private routerService: RouterService,
         private httpClient: HttpClient){
            this.reminderAPIURL = 'http://localhost:8004/api/reminder/' + this.authenticationService.getUserId();
            console.log(this.reminderAPIURL);
            this.reminders = new Array<Reminder>();
            this.reminderSubject = new BehaviorSubject<Array<Reminder>>(this.reminders);
            this.fetchRemindersFromServer();
        }

    ngOnInit(){
        
    }

    fetchRemindersFromServer(){
        this.httpClient.get<Array<Reminder>>(this.reminderAPIURL,{
            headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
        }).subscribe(
            next => {
                console.log(next);
                this.reminders = next;
                this.reminderSubject.next(this.reminders);
            },
            err => {
                console.log(err);
            }
        )
    }

    getAllReminders() : BehaviorSubject<Array<Reminder>>{
        return this.reminderSubject;
    }

    async addReminder(noteReminder: NoteReminder, noteId: Number, noteName: string) : Promise<boolean>{
        let _reminder: Reminder = new Reminder(noteReminder.description, noteReminder.name, noteReminder.type,
            noteReminder.createdBy, noteReminder.reminderTime, noteId, noteName);
        const addedReminder = await this.httpClient.post<Reminder>(this.reminderAPIURL, _reminder, 
            {
                headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
            }).toPromise();
        console.log(addedReminder);
        const rPromise: Promise<boolean> = new Promise<boolean>((res,rej) => {
            if(addedReminder && addedReminder!=null){
                this.reminders.push(addedReminder);
                this.reminderSubject.next(this.reminders);
                res(true);
            } else {
                rej(false);
            }
        });
        return rPromise;        
    }

    async deleteReminder(reminderName: string, noteId: Number) : Promise<boolean>{
        const result = await this.httpClient.delete<Boolean>(this.reminderAPIURL + '/' + noteId + '/' + reminderName, 
            {
                headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
            }).toPromise();
        const rPromise: Promise<boolean> = new Promise<boolean>((res,rej) => {
            if(result === true){
                let remIndex: number = this.reminders.findIndex(rem => rem.noteId === noteId && rem.name.toUpperCase() === reminderName.toUpperCase());
                this.reminders.splice(remIndex, 1);
                this.reminderSubject.next(this.reminders);
                res(true);
            } else {
                rej(false);
            }
        });
        return rPromise;        
    }

    async editReminder(noteReminder: NoteReminder, noteId: Number, noteName: string) : Promise<boolean>{
        let _reminder: Reminder = new Reminder(noteReminder.description, noteReminder.name, noteReminder.type,
            noteReminder.createdBy, noteReminder.reminderTime, noteId, noteName);
        const updatedReminder = await this.httpClient.put<Reminder>(this.reminderAPIURL + '/' + noteId + '/' + noteReminder.name, _reminder, 
            {
                headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
            }).toPromise();
        console.log(updatedReminder);
        const rPromise: Promise<boolean> = new Promise<boolean>((res,rej) => {
            if(updatedReminder && updatedReminder!=null){
                let arrRem: Reminder = this.getReminderById(_reminder.name, noteId);
                Object.assign(arrRem,updatedReminder);
                this.reminderSubject.next(this.reminders);
                res(true);
            } else {
                rej(false);
            }
        });
        return rPromise;        
    }

    getReminderById(remName: String, noteId: Number) : Reminder{
        return this.reminders.find(rem => rem.noteId === noteId && rem.name.toUpperCase() === remName.toUpperCase());
    }

}