import { Component, OnInit, Inject } from '@angular/core';
import { NotesService } from '../services/notes.service';
import { ReminderService } from '../services/reminder.service';
import { MAT_DIALOG_DATA, MatDialogRef, MatDatepicker, MatDatepickerToggle } from '@angular/material';
import { FormGroup, FormControl, FormBuilder, Validator, Validators } from '@angular/forms';
import { Note } from '../note';
import { Reminder } from '../reminder';
import { NoteReminder } from '../noteReminder'; 
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-reminder',
  templateUrl: './reminder.component.html',
  styleUrls: ['./reminder.component.css']
})
export class ReminderComponent implements OnInit {

  private note: Note;
  private reminder: Reminder;
  private noteReminder: NoteReminder;
  private isNew: boolean;
  private userId: string;
  private closeBtn: boolean = true;
  private btnEnable: boolean = true;
  

  private name: FormControl;
  private description: FormControl;
  private reminderTime: FormControl;
  private reminderFormGroup: FormGroup;
  private formReady: boolean = false;

  constructor(private notesService: NotesService, private reminderService: ReminderService,
    @Inject(MAT_DIALOG_DATA) private data, private matDialogRef: MatDialogRef<ReminderComponent>,
    private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.formReady = false;

    this.userId = this.data.userID;
    this.note = this.data.note;
    this.isNew = this.data.isNew;
    if(this.isNew){
      this.noteReminder = new NoteReminder('','','',this.userId,'');
    } else {
      this.noteReminder = this.data.reminder;
    }  
    
    let reminderTimeStr: string = '';
    if(this.noteReminder.reminderTime !== null && this.noteReminder.reminderTime.length > 0){
      let reminderTimeValue : Date = new Date(this.noteReminder.reminderTime);
      reminderTimeStr += reminderTimeValue.getFullYear() + '-' + reminderTimeValue.getMonth();
      reminderTimeStr += '-' + reminderTimeValue.getDay() + ' ' + reminderTimeValue.getHours();
      reminderTimeStr += '-' + reminderTimeValue.getMinutes() + ' ' + reminderTimeValue.getSeconds();
    }
    

    this.name = new FormControl(this.noteReminder.name, [Validators.required, Validators.minLength(5)]);    
    this.description = new FormControl(this.noteReminder.description, [Validators.minLength(10)]);
    this.reminderTime = new FormControl(reminderTimeStr, [Validators.required]);
    if(this.isNew === false){
      this.name.disable();
      //this.description.disable();
      //this.reminderTime.disable();
    } 
    this.reminderFormGroup = this.formBuilder.group(
      { 
        'name' : this.name,
        'description' : this.description,
        'reminderTime' : this.reminderTime
      }
    );

    this.formReady = true;
  }

  async addReminder() {
    this.closeBtn = false;
    this.btnEnable = false;
    this.noteReminder.name = this.name.value;
    let remIndex = -1;
    if(this.note.reminders != null && this.note.reminders.length > 0){
      remIndex = this.note.reminders.findIndex(rem => rem.name.toUpperCase() === this.noteReminder.name.toUpperCase());
    }    
    if(remIndex >= 0){
      alert(`Reminder named ${this.noteReminder.name} already exists`);
      this.closeBtn = true;
      this.btnEnable = true;
    } else {
      this.noteReminder.description = this.description.value;
      this.noteReminder.reminderTime = this.reminderTime.value;
      console.log(this.noteReminder);
      if(this.note.id < 0){
        await Promise.resolve(this.notesService.addReminderToList(this.noteReminder)).then( next => {
          console.log(next);
          this.matDialogRef.close('Added Reminder');
        });
      } else {
        await Promise.resolve(this.notesService.addReminder(this.note.id,this.noteReminder)).then(
          next => {
            console.log(next);         
            if(next){
              this.noteReminder = new NoteReminder(next.description,next.name,next.type,next.createdBy,next.reminderTime);
              console.log(this.noteReminder);
              Promise.resolve(this.reminderService.addReminder(this.noteReminder, this.note.id, this.note.title)).then(
                success => { 
                    if(success) {
                      console.log(success);
                      this.matDialogRef.close(this.noteReminder);
                    }
                }, fail => {
                  console.log(fail);
                  this.matDialogRef.close("Reminder addition failed");
                }
              );            
            } else {
              this.matDialogRef.close("Reminder addition failed");
            }
          }, err => {
            console.log(err);
            this.matDialogRef.close("Reminder addition failed");
          }
        );
      }
    }
  }


  async editReminder() {
    this.closeBtn = false;
    this.btnEnable = false;
    this.noteReminder.name = this.name.value;
    this.noteReminder.description = this.description.value;
    this.noteReminder.reminderTime = this.reminderTime.value;

    await Promise.resolve(this.notesService.editReminder(this.note.id,this.noteReminder.id,this.noteReminder)).then(
      next => {
        console.log(next);
        if(next === true){
          this.reminderService.editReminder(this.noteReminder, this.note.id, this.note.title);
          this.matDialogRef.close("Updated Reminder");
        } else {
          this.matDialogRef.close("Reminder update failed");
        }
      }, err => {
        console.log(err);
        this.matDialogRef.close("Reminder update failed");
      }
    );
  }

  async deleteReminder() {
    this.closeBtn = false;
    this.btnEnable = false;
    this.noteReminder.name = this.name.value;
    this.noteReminder.description = this.description.value;
    this.noteReminder.reminderTime = this.reminderTime.value;

    await Promise.resolve(this.notesService.deleteReminder(this.note.id,this.noteReminder.id)).then(
      next => {
        console.log(next);
        if(next === true){
          this.reminderService.deleteReminder(this.noteReminder.name, this.note.id);
          this.matDialogRef.close("Delete Reminder");
        } else {
          this.matDialogRef.close("Reminder deletion failed");
        }
      }, err => {
        console.log(err);
        this.matDialogRef.close("Reminder deletion failed");
      }
    );
  }

  closeDialog(){
    this.matDialogRef.close('No Action');
  }

}
