﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReminderService.API.Models;

namespace ReminderService.API.Repository
{
    public interface IReminderRepository
    {
        ReminderUser CreateReminder(ReminderUser reminderUser);
        bool AddReminder(string userId, Reminder reminder);
        bool DeleteReminder(string userId,int noteId, string reminderName);
        bool UpdateReminder(string userId, int noteId, string reminderName, Reminder reminder);
        ReminderUser GetReminderUserById(string userId);
        List<Reminder> GetAllReminders(string userId);
    }
}
