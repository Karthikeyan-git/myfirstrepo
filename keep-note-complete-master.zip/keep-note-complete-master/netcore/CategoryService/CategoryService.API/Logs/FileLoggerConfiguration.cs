﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CategoryService.API.Logs
{
    public class FileLoggerConfiguration
    {
        public String LogFileDir { get; set; }

        public String LogFileName { get; set; }

        public float MaxFileSizeInMB { get; set; }

        public LogLevel LogLevel { get; set; }
    }
}
