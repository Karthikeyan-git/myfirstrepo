export class Reminder{
    id: Number;
    description: String;
    name: String;
    type: String;
    createdBy: String;
    reminderTime: String;
    noteId: Number;
    noteName: string;

    constructor(description: String, name: String, type: String, createdBy: String,reminderTime: String,
        noteId: Number, noteName: string){
        this.id=0;
        this.description=description;
        this.name=name;
        this.type=type;
        this.createdBy=createdBy;
        this.reminderTime = reminderTime;
        this.noteId = noteId;
        this.noteName = noteName;
    }
}