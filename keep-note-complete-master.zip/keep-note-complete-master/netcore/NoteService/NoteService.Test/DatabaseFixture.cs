﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Extensions.Configuration;
using NoteService.API.Models;

namespace NoteService.Test
{
    public class DatabaseFixture : IDisposable
    {
        private IConfigurationRoot configuration;
        public INoteContext context;
        public DatabaseFixture()
        {
            var builder = new ConfigurationBuilder().AddJsonFile("appsettings.json");

            configuration = builder.Build();
            context = new NoteContext(configuration);
            context.Notes.InsertMany(new List<NoteUser>
            {
                new NoteUser{
                    UserId="UserOne", Notes=new List<Note>{
                        new Note { Id=13331, Category= new Category{Id=1001, Name="Sports", CreatedBy="UserOne", Description="All about sports", CreationDate=new DateTime() },
                        Text="Sample Note", CreatedBy="UserOne", Reminders=new List<Reminder>{ new Reminder { Id = 2001, Name = "Sports", CreatedBy = "UserOne", Description = "sports reminder", CreationDate = new DateTime(), Type = "email" } } ,
                        Title="Sample", CreationDate=new DateTime()},
                        new Note { Id=13333, Category= new Category{Id=1001, Name="Sports", CreatedBy="UserOne", Description="All about sports", CreationDate=new DateTime() },
                        Text="Sample Note", CreatedBy="UserOne", Reminders=new List<Reminder>{ new Reminder { Id = 2001, Name = "Sports", CreatedBy = "UserOne", Description = "sports reminder", CreationDate = new DateTime(), Type = "email" } } ,
                        Title="Sample", CreationDate=new DateTime()}
                    }
                },

                new NoteUser{
                    UserId="UserTwo", Notes=new List<Note>{
                        new Note { Id=1333341, Category= new Category{Id=1002, Name="Sports", CreatedBy="UserTwo", Description="All about sports", CreationDate=new DateTime() },
                        Text="Sample Note", CreatedBy="UserTwo", Reminders=new List<Reminder>{ new Reminder { Id = 2002, Name = "Sports", CreatedBy = "UserTwo", Description = "sports reminder", CreationDate = new DateTime(), Type = "email" } } ,
                        Title="Sample", CreationDate=new DateTime()},
                        new Note { Id=1333343, Category= new Category{Id=1002, Name="Sports", CreatedBy="UserTwo", Description="All about sports", CreationDate=new DateTime() },
                        Text="Sample Note", CreatedBy="UserTwo", Reminders=new List<Reminder>{ new Reminder { Id = 2002, Name = "Sports", CreatedBy = "UserTwo", Description = "sports reminder", CreationDate = new DateTime(), Type = "email" } } ,
                        Title="Sample", CreationDate=new DateTime()}
                    }
                }

            });
        }
        public void Dispose()
        {
            context = null;
        }
    }
}
