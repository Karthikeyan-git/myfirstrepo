import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';
import { UserService } from '../services/user.service';
import { User } from '../user';
import { UserInfo } from '../userInfo';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user = new User('','','','');
  userId = new FormControl(this.user.userId);
  firstName = new FormControl(this.user.firstName);
  lastName = new FormControl(this.user.lastName);
  password = new FormControl(this.user.password);
  registerForm: FormGroup;
  submitMessage: string;
  isFormReady = false;
  @ViewChild(FormGroupDirective) registerFromDirective;

  constructor(private authenticationService: AuthenticationService, private routerService: RouterService,
    private userService: UserService, private formBuilder: FormBuilder ) { }

  ngOnInit() {
    this.userId.setValidators([Validators.required, Validators.minLength(5)]);
    this.firstName.setValidators([Validators.required]);
    this.password.setValidators([Validators.required,Validators.minLength(8)]);
    this.registerForm=this.formBuilder.group({
      'userId': this.userId,
      'firstName': this.firstName,
      'lastName': this.lastName,
      'password': this.password
    });
    this.isFormReady = true;
  }

  async registerUser(){
    let _user: User = new User(this.userId.value, this.firstName.value, this.lastName.value, this.password.value);
    console.log(_user);
    await this.authenticationService.registerUser(_user).then(
      next => {
        this.userService.addUser(_user);
        this.routerService.routeToDashboard();           
      },
      err => {
        if(err instanceof ErrorEvent){
          if(err.error.statuscode === 404){
            this.submitMessage=err.message;
          } else if(err.error.statuscode === 409){
            this.submitMessage=`${this.userId} already used, please try with a different userId`;
          }
        } else {
          this.submitMessage = err.error.message;
        }        
      }      
    );
    this.registerFromDirective.reset();
  }

}
