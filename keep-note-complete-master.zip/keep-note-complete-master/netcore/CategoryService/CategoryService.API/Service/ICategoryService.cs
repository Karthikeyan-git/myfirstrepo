﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CategoryService.API.Models;

namespace CategoryService.API.Service
{
    public interface ICategoryService
    {
        CategoryUser CreateCategory(CategoryUser categoryUser);
        bool AddCategory(string userId, Category category);
        bool DeleteCategory(string userId, string categoryName);
        bool UpdateCategory(string userId, string categoryName, Category category);
        CategoryUser GetCategoryUserById(string userId);
        List<Category> GetAllCategoriesByUserId(string userId);
    }
}
