import { Component, OnInit, Inject } from '@angular/core';
import { Category } from '../category';
import { CategoryService } from '../services/category.service';
import { CategoryAPIService } from '../services/categoryAPI.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material'; 
import { AddEditModel } from '../addEditModel';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  
  category: Category;
  name: FormControl;
  description: FormControl;
  categoryForm: FormGroup;
  submitMessage: string;
  closeBtn: boolean =  true;
  btnEnable: boolean = true;

  constructor(private categoryService: CategoryService, private categoryAPIService: CategoryAPIService, private matDialogRef: MatDialogRef<CategoryComponent>,
    @Inject(MAT_DIALOG_DATA) private addEditModel: AddEditModel, private formBuilder: FormBuilder) { }

  ngOnInit() {
    if(this.addEditModel.isNew){
      this.category=new Category();
      this.name = new FormControl(this.category.name);      
      this.description = new FormControl(this.category.description);      
    } else {
      this.category = this.categoryService.getCategoryById(this.addEditModel.crId);      
      this.name = new FormControl(this.category.name);
      this.name.disable();
      this.description = new FormControl(this.category.description);
      //this.description.disable();
    }
    console.log(this.category);
    this.name.setValidators([Validators.required,Validators.minLength(5)]);
    this.description.setValidators([Validators.required]);
    this.categoryForm =  this.formBuilder.group(
      {
        'name': this.name,
        'description': this.description
      }
    );
  }

  // Submit(){
  //   this.category.name = this.name.value;
  //   this.category.description = this.description.value;
  //   if(this.addEditModel.isNew){
  //     this.categoryService.addCategory(this.category);
      
  //   } else {
  //     this.categoryService.editCategory(this.category);
  //   }
  // }

  async addCategory(){
    this.closeBtn = false;
    this.btnEnable = false;
    let categories: Array<Category>;
    await this.categoryService.getDistinctCategories().toPromise().then( next => {
      categories = next;
    }).catch( err => {
      categories = new Array<Category>();
    });
    if(categories!=null && categories.length > 0 && categories.find(
      ct=>ct.name.toUpperCase() == this.name.value.toUpperCase())){
        alert("Category already exists");
        this.btnEnable = true;
        this.closeBtn = true;
    } else {
      this.category.name = this.name.value;
      this.category.description = this.description.value;
      if(this.addEditModel.noteId == -1){
        this.categoryService.addCategoryToList(this.category);
        this.matDialogRef.close(this.category);
      } else {
        await Promise.resolve(this.categoryService.addCategory(this.addEditModel.noteId,this.category)).then(
          next => {
            this.categoryAPIService.addCategory(this.category);
            this.matDialogRef.close(this.category);
          }
        ).catch(
          err => this.matDialogRef.close('Category addition failed')
        ); 
      }           
    }    
  }

  async editCategory(){
    this.closeBtn = false;
    this.btnEnable = false;
    this.category.name = this.name.value;
    this.category.description = this.description.value;
    if(this.addEditModel.noteId == -1){
      this.categoryService.addEditCategoryToList(this.category);
      this.matDialogRef.close('Saved Category');
    } else {      
      await Promise.resolve(this.categoryService.editCategory(this.addEditModel.noteId,this.addEditModel.crId,this.category)).then(
        next =>  {
          this.categoryAPIService.editCategory(this.category);
          this.matDialogRef.close('Saved Category');
        },
        err => this.matDialogRef.close('Category updation failed')
      );     
    }
  }

  async deleteCategory(){
    this.closeBtn = false;
    this.btnEnable = false;
    if(this.addEditModel.noteId == -1){
      this.categoryService.deleteCategoryFromList(this.category);
      this.matDialogRef.close('Saved Category');
    } else { 
      await this.categoryService.deleteCategory(this.addEditModel.noteId,this.addEditModel.crId).then(
        next => {
          if(next == true)
          {
            this.categoryAPIService.deleteCategory(this.category);
            this.matDialogRef.close('Deleted Category');
          } else {
            this.matDialogRef.close('Delete Category failed');
          }
        } 
      ).catch( err => {
        this.matDialogRef.close('Delete Category failed');
      });
    }
  }

  closeDialog(){
    this.matDialogRef.close('No Action');
  }
}
