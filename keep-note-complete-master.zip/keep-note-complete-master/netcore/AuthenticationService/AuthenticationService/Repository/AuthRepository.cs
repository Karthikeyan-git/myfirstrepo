﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Models;

namespace AuthenticationService.Repository
{
    public class AuthRepository : IAuthRepository
    {
        private IAuthenticationContext _authenticationContext;
        public AuthRepository(IAuthenticationContext authenticationContext)
        {
            _authenticationContext = authenticationContext;            
        }

        public User FindUserById(string userId)
        {
            return _authenticationContext.Users.FirstOrDefault(user => user.UserId == userId);
        }

        public User LoginUser(string userId, string password)
        {
            return _authenticationContext.Users.FirstOrDefault(user => user.UserId == userId && user.Password == password);
        }

        public bool RegisterUser(User user)
        {
            _authenticationContext.Users.Add(user);
            return _authenticationContext.SaveChanges()>0;
        }
    }
}
