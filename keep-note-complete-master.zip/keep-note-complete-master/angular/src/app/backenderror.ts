export class BackendError{
    public error: string;
}