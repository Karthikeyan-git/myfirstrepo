export class NoteReminder{
    id: Number;
    description: string;
    name: string;
    type: string;
    createdBy: string;
    reminderTime: string;

    constructor(description: string,name: string, type: string, createdBy: string, reminderTime: string){
        this.id=0;
        this.description=description;
        this.name = name;
        this.type = type;
        this.createdBy = createdBy;
        this.reminderTime = reminderTime;
    }
}