﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReminderService.API.Models
{
    public class ReminderUser
    {
        [BsonId]
        public string UserId { get; set; }
        public List<Reminder> Reminders { get; set; }
    }
}
