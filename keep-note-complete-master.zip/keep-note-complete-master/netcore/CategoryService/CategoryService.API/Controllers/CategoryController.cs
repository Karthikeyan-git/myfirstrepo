﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CategoryService.API.Service;
using CategoryService.API.Models;
using CategoryService.API.Exceptions;
using CategoryService.API.Extensions;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CategoryService.API.Controllers
{
    [Route("api/[controller]")]
    [ExceptionLogger]
    //[TypeFilter(typeof(LoggingAspect))]
    [Authorize]
    public class CategoryController : Controller
    {
        private readonly ICategoryService service;

        public CategoryController(ICategoryService _service)
        {
            this.service = _service;
        }
        // GET: api/<controller>
        //[HttpGet]
        //[Route("GetById")]
        //public IActionResult Get(int categoryId)
        //{
        //    return Ok(service.GetCategoryById(categoryId));
        //}

        // GET api/<controller>/5
        [HttpGet("{userId}")]
        public IActionResult Get(string userId)
        {
            return Ok(service.GetAllCategoriesByUserId(userId));
        }

        // POST api/<controller>
        [HttpPost("{userId}")]
        public IActionResult Post(string userId,[FromBody]Category category)
        {
            if (ModelState.IsValid)
            {
                category.CreatedBy = userId;
                category.CreationDate = DateTime.Now;
                return Created("api/Category", service.AddCategory(userId,category));
            }
            else
            {
                throw new ModelInvalidException(typeof(Category).Name);
            }
        }

        // PUT api/<controller>/5
        [HttpPut("{userId}/{categoryName}")]
        public IActionResult Put(string userId,string categoryName, [FromBody]Category category)
        {
            if (ModelState.IsValid)
            {
                return Ok(service.UpdateCategory(userId, categoryName, category));
            }
            else
            {
                throw new ModelInvalidException(typeof(Category).Name);
            }
        }

        // DELETE api/<controller>/5
        [HttpDelete("{userId}/{categoryName}")]
        public IActionResult Delete(string userId, string categoryName)
        {
            return Ok(service.DeleteCategory(userId, categoryName));
        }
    }
}
