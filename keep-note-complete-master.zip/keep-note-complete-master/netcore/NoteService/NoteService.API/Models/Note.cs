﻿using System;
using System.Collections.Generic;
using MongoDB.Bson.Serialization.Attributes;

namespace NoteService.API.Models
{
    public class Note
    {
        [BsonId]
        public long Id { get; set; }
        public string Title { get; set; }
        public string Text { get; set; }
        public DateTime CreationDate { get; set; }
        public string CreatedBy { get; set; }
        public List<Category> Categories { get; set; }
        public List<Reminder> Reminders { get; set; }
    }
}
