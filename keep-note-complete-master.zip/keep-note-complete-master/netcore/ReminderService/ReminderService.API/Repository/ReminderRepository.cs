﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Driver;
using ReminderService.API.Models;

namespace ReminderService.API.Repository
{
    public class ReminderRepository : IReminderRepository
    {
        private readonly IReminderContext reminderContext;

        public ReminderRepository(IReminderContext _reminderContext)
        {
            reminderContext = _reminderContext;
        }

        public ReminderUser CreateReminder(ReminderUser reminderUser)
        {
            int id = 0;
            foreach (Reminder r in reminderUser.Reminders)
            {
                r.Id = ++id;
            }
            reminderContext.ReminderUsers.InsertOne(reminderUser);
            return GetReminderUserById(reminderUser.UserId);
        }

        public bool AddReminder(string userId, Reminder reminder)
        {
            ReminderUser ru = GetReminderUserById(userId);
            if(ru.Reminders!=null && ru.Reminders.Count > 0)
            {
                reminder.Id = ru.Reminders.Max<Reminder>(r => r.Id) + 1;
            } else
            {
                ru.Reminders = new List<Reminder>();
                reminder.Id = 1;
            }            
            var updateDef = Builders<ReminderUser>.Update.Push<Reminder>(remUser => remUser.Reminders, reminder);
            UpdateResult ur = reminderContext.ReminderUsers.UpdateOne<ReminderUser>(remUser => remUser.UserId == userId, updateDef);
            return ur.IsAcknowledged && ur.ModifiedCount == 1;
        }

        public bool DeleteReminder(string userId, int noteId, string reminderName)
        {
           var pullOperatorDefinition = Builders<ReminderUser>.Update.PullFilter(ru => ru.Reminders, Builders<Reminder>.Filter.And(new List<FilterDefinition<Reminder>>{
                  Builders<Reminder>.Filter.Eq(r => r.Name, reminderName),
                  Builders<Reminder>.Filter.Eq(r => r.NoteId, noteId)}));
            //below also works, using filterdef & filterdef => &, | , ! operators are allowed for combining multiple filters
            //var pullOperatorDefinition = Builders<ReminderUser>.Update.PullFilter(ru => ru.Reminders,
            //    Builders<Reminder>.Filter.Eq(r => r.Name, reminderName) & Builders<Reminder>.Filter.Eq(r => r.NoteId, noteId));
            UpdateResult updateResult = reminderContext.ReminderUsers.UpdateOne(ru => ru.UserId == userId, pullOperatorDefinition);
            return updateResult.IsAcknowledged && updateResult.ModifiedCount > 0;
        }

        public List<Reminder> GetAllReminders(string userId)
        {
            return reminderContext.ReminderUsers.Find(ru => ru.UserId == userId).FirstOrDefault().Reminders;
        }

        public ReminderUser GetReminderUserById(string reminderUserId)
        {
            ReminderUser reminder = reminderContext.ReminderUsers.Find(r => r.UserId == reminderUserId).FirstOrDefault();
            return reminder;
        }

        public bool UpdateReminder(string userId, int noteId, string reminderName, Reminder reminder)
        {
            var updateDef = Builders<ReminderUser>.Update.Set<Reminder>("Reminders.$", reminder);
            reminderContext.ReminderUsers.FindOneAndUpdate(ru => ru.UserId == userId && ru.Reminders.Any(rem => rem.NoteId == noteId && rem.Name.ToUpper() == reminderName.ToUpper()), updateDef);
            return true;
        }


    }
}
