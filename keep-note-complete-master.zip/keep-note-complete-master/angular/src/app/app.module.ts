import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Route, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatToolbarModule, MatExpansionModule, MatButtonModule, MatIconModule,
  MatSelectModule, MatInputModule, MatCardModule, MatListModule,
  MatGridListModule, MatDialogModule, MatSidenavModule, MatDividerModule, MatSnackBarModule,
  MatMenuModule, MatDatepickerModule, MatNativeDateModule } from '@angular/material';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EditNoteOpenerComponent } from './edit-note-opener/edit-note-opener.component';
import { EditNoteViewComponent } from './edit-note-view/edit-note-view.component';
import { HeaderComponent } from './header/header.component';
import { ListViewComponent } from './list-view/list-view.component';
import { LoginComponent } from './login/login.component';
import { NoteComponent } from './note/note.component';
import { NoteTakerComponent } from './note-taker/note-taker.component';
import { NoteViewComponent } from './note-view/note-view.component';
import { AuthenticationService } from './services/authentication.service';
import { NotesService } from './services/notes.service';
import { RouterService } from './services/router.service';
import { CategoryService } from './services/category.service';
import { ReminderService } from './services/reminder.service';
import { CategoryAPIService } from './services/categoryAPI.service';
import { UserService } from './services/user.service';
import { AppComponent } from './app.component';
import { CanActivateRouteGuard } from './can-activate-route.guard';
import { ReminderComponent } from './reminder/reminder.component';
import { CategoryComponent } from './category/category.component';
import { RegisterComponent } from './register/register.component';
import { NoteEditorComponent } from './note-editor/note-editor.component';
import { ReminderViewComponent } from './reminder-view/reminder-view.component';
// import { HTTP_INTERCEPTORS } from '@angular/common/http';
// import { AuthHttpInterceptor } from './authHttpInterceptor';

const routes: Route[] = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate:[CanActivateRouteGuard],
    children: [
      { path: 'view/noteview', component: NoteViewComponent },
      { path: 'view/listview', component: ListViewComponent },
      { path: 'view/noteview/:catRem', component: NoteViewComponent },
      { path: 'view/listview/:catRem', component: ListViewComponent },
      { path: 'edit/:noteID', component:EditNoteOpenerComponent },
      { path: 'view/reminderview/:catRem', component: ReminderViewComponent },
      { path: '**', redirectTo: 'view/noteview', pathMatch: 'prefix' }
    ]
  },
  { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    DashboardComponent,
    EditNoteOpenerComponent,
    HeaderComponent,
    ListViewComponent,
    LoginComponent,
    NoteComponent,
    NoteTakerComponent,
    NoteViewComponent,
    EditNoteViewComponent,
    AppComponent,
    ReminderComponent,
    CategoryComponent,
    RegisterComponent,
    NoteEditorComponent,
    ReminderViewComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    MatToolbarModule,
    MatExpansionModule,
    MatButtonModule,
    MatInputModule,
    MatIconModule,
    MatCardModule,
    MatListModule,
    MatGridListModule,
    MatDialogModule,
    MatSelectModule,
    MatSidenavModule,
    MatDividerModule,
    MatSnackBarModule,
    MatMenuModule,
    MatDatepickerModule,
    MatNativeDateModule
   ],
  providers: [
    //{provide : HTTP_INTERCEPTORS, useClass: AuthHttpInterceptor, multi: true},
    CanActivateRouteGuard,
    AuthenticationService,
    NotesService,
    RouterService,
    CategoryService,
    ReminderService,
    CategoryAPIService,
    UserService
  ],
  entryComponents: [ CategoryComponent, ReminderComponent ],
  bootstrap: [ AppComponent ]
})

export class AppModule { }
