﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Driver;

namespace AuthenticationService.Models
{
    public interface IAuthenticationMongoContext
    {
        IMongoCollection<User> users { get; }
    }
}
