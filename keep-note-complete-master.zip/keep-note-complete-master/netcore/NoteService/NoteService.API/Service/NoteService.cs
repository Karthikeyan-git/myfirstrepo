﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NoteService.API.Models;
using NoteService.API.Repository;
using NoteService.API.Exceptions;

namespace NoteService.API.Service
{
    public class NoteService : INoteService
    {
        private readonly INoteRepository noteRepository;

        public NoteService(INoteRepository _noteRepository)
        {
            noteRepository = _noteRepository;
        }

        public Note AddNote(string userId, Note note)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                return CreateNote(new NoteUser { UserId = userId, Notes = new List<Note> { note } });
            }
            else
            {
                return noteRepository.AddNote(userId, note);
            }
        }

        public Note CreateNote(NoteUser noteUser)
        {
            NoteUser _noteUser = noteRepository.GetNoteUserById(noteUser.UserId);
            if (_noteUser != null)
            {
                throw new NoteAlreadyExistsException("NoteUser already exists for this id");
            }
            else
            {
                return noteRepository.CreateNote(noteUser);
            }
        }

        public bool DeleteNote(string userId, int noteId)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                Note _note = noteUser.Notes.FirstOrDefault(n => n.Id == noteId);
                if (_note == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else
                {
                    return noteRepository.DeleteNote(userId, noteId);
                }
            }
        }

        public List<Note> GetAllNotes(string userId)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                return noteRepository.FindByUserId(userId);
            }
        }

        public Note GetNote(string userId, int noteId)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                if (noteUser.Notes == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else
                {
                    Note _note = noteUser.Notes.FirstOrDefault(n => n.Id == noteId);
                    if (_note == null)
                    {
                        throw new NoteNotFoundExeption("Note does not exist for this id");
                    }
                    else
                    {
                        return _note;
                    }
                }                
            }
        }

        public Note UpdateNote(int noteId, string userId, Note note)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                if (noteUser.Notes == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else
                {
                    Note _note = noteUser.Notes.FirstOrDefault(n => n.Id == noteId);
                    if (_note == null)
                    {
                        throw new NoteNotFoundExeption("Note does not exist for this id");
                    }
                    else
                    {
                        return noteRepository.UpdateNote(noteId, userId, note);
                    }
                }
            }
        }

        public List<Note> GetNotes(string userId, string categoryName)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                List<Note> notes = noteUser.Notes;
                if (notes == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else
                {
                    return notes.Where(note => note.Categories.Any(c => c.Name.ToUpper() == categoryName.ToUpper())).ToList();
                }
            }
        }

        public List<Category> GetAllCategories(string userId)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                List<Note> notes = noteUser.Notes;
                if (notes == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else
                {
                    List<Category> categories = new List<Category>();
                    notes.ForEach(note => categories.AddRange(note.Categories));
                    if (categories.Count > 0)
                    {
                        return categories;
                    }
                    else
                    {
                        throw new NoteNotFoundExeption("Category doesnot exist");
                    }
                }
            }
        }

        public List<Category> GetAllCategories(string userId, int noteId)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                if (noteUser.Notes == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else
                {
                    Note note = noteUser.Notes.FirstOrDefault(nt => nt.Id == noteId);
                    if (note == null)
                    {
                        throw new NoteNotFoundExeption("Note does not exist for this id");
                    }
                    else
                    {
                        List<Category> categories = note.Categories;
                        if (categories.Count > 0)
                        {
                            return categories;
                        }
                        else
                        {
                            throw new NoteNotFoundExeption("Category doesnot exist");
                        }
                    }
                }
            }
        }

        public bool DeleteCategory(string userId, int noteId, int categoryId)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                Note _note = noteUser.Notes.FirstOrDefault(n => n.Id == noteId);
                if (_note == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else
                {
                    if (_note.Categories == null)
                    {
                        throw new NoteNotFoundExeption("Category does not exist for this note");
                    }
                    else
                    {
                        Category category = _note.Categories.FirstOrDefault(c => c.Id == categoryId);
                        if (category == null)
                        {
                            throw new NoteNotFoundExeption("Category does not exist for this id");
                        }
                        else
                        {
                            return noteRepository.DeleteCategory(userId, noteId, categoryId);
                        }
                    }
                }
            }
        }

        public Category AddCategory(string userId, int noteId, Category category)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                Note _note = noteUser.Notes.FirstOrDefault(n => n.Id == noteId);
                if (_note == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else
                {
                    if (_note.Categories != null && _note.Categories.Count > 0)
                    {
                        Category _category = _note.Categories.FirstOrDefault(c => c.Name.ToUpper() == category.Name.ToUpper());
                        if (_category != null)
                        {
                            throw new NoteAlreadyExistsException("Category already exist for this id");
                        }
                    } 
                    category.CreatedBy = userId;
                    category.CreationDate = DateTime.Today.Date;
                    return noteRepository.AddCategory(userId, noteId, category);                       
                }
            }
        }

        public Category EditCategory(string userId, int noteId, int categoryId, Category category)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                Note _note = noteUser.Notes.FirstOrDefault(n => n.Id == noteId);
                if (_note == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else
                {
                    if (_note.Categories == null)
                    {
                        throw new NoteNotFoundExeption("Category does not exist for this note");
                    }
                    else
                    {
                        Category _category = _note.Categories.FirstOrDefault(c => c.Id == category.Id);
                        if (_category == null)
                        {
                            throw new NoteAlreadyExistsException("Category doesnot exist for this id");
                        }
                        else
                        {
                            category.CreatedBy = userId;
                            return noteRepository.EditCategory(userId, noteId, categoryId, category);
                        }
                    }
                }
            }
        }

        public List<Category> GetDistinctCategories(string userId)
        {
            List<Category> distinctCategories = new List<Category>();
            try
            {
                distinctCategories = GetAllCategories(userId);
                distinctCategories = distinctCategories.Distinct<Category>(new CategoryComparator()).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Note Service : GetDistinctCategories userID : " + ex);
            }
            return distinctCategories;
        }

        public List<Category> GetDistinctCategories(string userId, int noteId)
        {
            List<Category> distinctCategories = new List<Category>();
            distinctCategories = GetDistinctCategories(userId);
            if (distinctCategories.Count > 0)
            {
                try
                {
                    List<Category> noteCategories = GetAllCategories(userId, noteId);
                    distinctCategories = distinctCategories.Except<Category>(noteCategories, new CategoryComparator()).ToList();
                }
                catch (NoteNotFoundExeption ex)
                {
                    Console.WriteLine("Note Service : GetDistinctCategories userID NoteID : " + ex);
                }
            }
            return distinctCategories;
        }

        public bool DeleteReminder(string userId, int noteId, int reminderId)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                Note _note = noteUser.Notes.FirstOrDefault(n => n.Id == noteId);
                if (_note == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else
                {
                    
                    Reminder reminder = _note.Reminders.FirstOrDefault(rem => rem.Id == reminderId);
                    if (reminder == null)
                    {
                        throw new NoteNotFoundExeption("Category does not exist for this id");
                    }
                    else
                    {
                        return noteRepository.DeleteReminder(userId, noteId, reminderId);
                    }
                }
            }
        }

        public Reminder AddReminder(string userId, int noteId, Reminder reminder)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                Note _note = noteUser.Notes.FirstOrDefault(n => n.Id == noteId);
                if (_note == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else
                {
                    if(_note.Reminders != null && _note.Reminders.Count > 0)
                    {
                        Reminder _reminder = _note.Reminders.FirstOrDefault(c => c.Name.ToUpper() == reminder.Name.ToUpper());
                        if (_reminder != null)
                        {
                            throw new NoteAlreadyExistsException("Reminder already exist for this id");
                        }
                    }                   
                    reminder.CreatedBy = userId;
                    reminder.CreationDate = DateTime.Today.Date;
                    return noteRepository.AddReminder(userId, noteId, reminder);
                }
            }
        }

        public Reminder EditReminder(string userId, int noteId, int reminderId, Reminder reminder)
        {
            NoteUser noteUser = noteRepository.GetNoteUserById(userId);
            if (noteUser == null)
            {
                throw new NoteNotFoundExeption("NoteUser does not exist for this id");
            }
            else
            {
                Note _note = noteUser.Notes.FirstOrDefault(n => n.Id == noteId);
                if (_note == null)
                {
                    throw new NoteNotFoundExeption("Note does not exist for this id");
                }
                else if (_note.Reminders != null)
                {
                    Reminder _reminder = _note.Reminders.FirstOrDefault(c => c.Name.ToUpper() == reminder.Name.ToUpper());
                    if (_reminder != null)
                    {
                        reminder.CreatedBy = userId;
                        return noteRepository.EditReminder(userId, noteId, reminderId, reminder);
                    }
                    else
                    {
                        throw new NoteNotFoundExeption("Reminder doesnot exist for this id");
                    }
                }
                else
                {
                    throw new NoteNotFoundExeption("Reminder doesnot exist for this id");
                }
            }
        }
    }
}
