﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NoteService.API.Models
{
    public class CategoryComparator : IEqualityComparer<Category>
    {
        public bool Equals(Category x, Category y)
        {
            return x.Name.ToUpper().Equals(y.Name.ToUpper());
        }

        public int GetHashCode(Category obj)
        {
            return obj.Name.GetHashCode();
        }
    }
}
