export class User {
    userId: string;
    password: string;
    firstName: string;
    lastName: string;
    addedDate: Date;

    constructor(userId: string, firstName: string, lastName: string, password: string){
        this.userId=userId;
        this.firstName='';
        this.lastName='';
        this.password=password;
        this.addedDate=new Date();
    }
}