import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { User } from '../user';

@Injectable()
export class UserService{
    private userAPIURL: string;

    constructor(private httpClient: HttpClient, private authenticationService: AuthenticationService){
        this.userAPIURL = 'http://localhost:8002/api/user/';
    }

    addUser(user: User){
        this.httpClient.post(this.userAPIURL,user,{
            headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
        }).subscribe(
            next => console.log(next),
            err => console.log(err)
        );
    }
}