import { Component, OnInit, Input, ViewChild  } from '@angular/core';
import { NotesService } from '../services/notes.service';
import { CategoryService } from '../services/category.service';
import { RouterService } from '../services/router.service';
import { AuthenticationService } from '../services/authentication.service';
import { ReminderService } from '../services/reminder.service';
import { FormControl, FormBuilder, FormGroup, Validators,FormGroupDirective } from '@angular/forms';
import { MatDialog, MatSnackBarConfig } from '@angular/material';
import { Note } from '../note';
import { Category } from '../category';
import { CategoryComponent } from '../category/category.component';
import { AddEditModel } from '../addEditModel';
import { MatSnackBar } from '@angular/material';
import { ReminderComponent } from '../reminder/reminder.component';
import { NoteReminder } from '../noteReminder';



@Component({
  selector: 'app-note-editor',
  templateUrl: './note-editor.component.html',
  styleUrls: ['./note-editor.component.css']
})
export class NoteEditorComponent implements OnInit {


  @Input() noteID : Number;
  categories: Array<Category>;
  reminders: Array<NoteReminder>;
  selectListCategories: Array<Category>;
  note: Note;
  submitMessage: string;
  isNewNote: Boolean = false;
  catSelected: Category;
  btnEnable: boolean = true;
  

  title = new FormControl('');
  text = new FormControl('');
  catList = new FormControl('');
  isFormReady: boolean = false;
  noteForm:  FormGroup;

  @ViewChild(FormGroupDirective) noteFormDirective;

  constructor(private notesService: NotesService, private categoryService: CategoryService,
    private formBuilder: FormBuilder, private routerService: RouterService, private reminderService: ReminderService,
    private matDialog: MatDialog, private authenticationService: AuthenticationService,
    private matSnackBar: MatSnackBar) { }

  async ngOnInit() {
    console.log(this.noteID);
    if(this.noteID>=0){
      this.isNewNote = false;
      this.note = this.notesService.getNoteById(this.noteID);
      //let notes: Note[] = await this.notesService.getNotes().toPromise();
      //this.note = notes.find(nt => nt.id == this.noteID);
      console.log(this.note);
      if(this.note.categories && this.note.categories != null) {
        this.categoryService.setCategories(this.note.categories);
      } else {
        this.categoryService.setCategories(new Array<Category>());
      }
      if(this.note.reminders && this.note.reminders != null) {
        this.notesService.setReminders(this.note.reminders);
      } else {
        this.notesService.setReminders(new Array<NoteReminder>());
      }
      console.log(this.note);
      this.title.setValue(this.note.title);
      this.text.setValue(this.note.text);
    } else {
      this.isNewNote = true;
      this.note = new Note();
      this.note.id=-1;
      this.categoryService.setCategories(new Array<Category>());
      this.notesService.setReminders(new Array<NoteReminder>());
    }
    this.categoryService.getCategories().subscribe(
      next => this.categories = next
    );
    
    this.notesService.getReminders().subscribe(
      next => this.reminders = next
    );

    this.selectListCategories = new Array<Category>();    
    if(this.noteID >= 0){
      await this.categoryService.getDistinctCategoriesOfNote(this.noteID).toPromise().then( next => {
        this.selectListCategories = next;
      }).catch( err => {
        this.selectListCategories = new Array<Category>();
      });
    } else {
      await this.categoryService.getDistinctCategories().toPromise().then( next => {
        this.selectListCategories = next;
      }).catch( err => {
        this.selectListCategories = new Array<Category>();
      });
    }    
    console.log(this.selectListCategories);


    this.title.setValidators([Validators.required, Validators.minLength(5)]);
    this.text.setValidators([Validators.required]);
    this.noteForm=this.formBuilder.group(
      {
        'title': this.title,
        'text': this.text,
        'catList': this.catList,
      }
    );
    this.isFormReady=true;
  }


  async SaveNote(){
    this.note.categories = this.categoryService.categories;
    this.note.reminders = this.notesService.reminders;
    this.note.text= this.text.value;
    this.note.title = this.title.value;
    this.btnEnable = false;
    console.log(this.note);
    console.log(this.isNewNote);
    if(this.isNewNote) {
      await this.notesService.addNote(this.note).then(
      next => {
        this.submitMessage='note added';
        this.addReminderForNewNote(next.id, next.title, next.reminders);
      },
      err => {        
        this.submitMessage='add note failed';
      }
    );
    } else {
      await this.notesService.editNote(this.note).then(
        next => {
          this.submitMessage='note updated';
        },
        err => {
          if(err instanceof ErrorEvent){
            if(err.error.statuscode === 401){
              this.routerService.routeToLogin();
            }
          }
          this.submitMessage='edit note failed';
        }
      );
    }
    this.openMatSnackBar(this.submitMessage);
    this.routerService.routeToDashboard();
    this.noteFormDirective.reset();
  }

  async AddCategoryFromList(){
    this.btnEnable = false;
    this.catSelected = this.catList.value;
    console.log(this.catSelected);
    console.log(this.note);
    if(this.isNewNote){
      console.log('Adding category from list to new note');
      this.categoryService.addCategoryToList(this.catSelected);
      //this.categories.push(this.catSelected);
      this.submitMessage = "Added category";
      this.openMatSnackBar(this.submitMessage);
    }
    // else if (this.note.categories!=null && this.note.categories.length > 0 && this.note.categories.find(
    //     ct=>ct.name.toUpperCase() == this.catSelected.name.toUpperCase())) {
    //   alert("Category already exists");
    // }
    else {
      await Promise.resolve(this.categoryService.addCategory(this.note.id,this.catSelected)).then(
        next => {
          this.submitMessage = "Added category";
          this.openMatSnackBar(this.submitMessage);
        },
        err => {
          this.submitMessage = "Category adition failed";
          this.openMatSnackBar(this.submitMessage);
        }
      );
    }
    this.btnEnable = true;
  }

  addCategoryOpen(){
    const addEditModel = new AddEditModel(this.authenticationService.getUserId(), this.note.id, -1,true);
    const dialogRef = this.matDialog.open(CategoryComponent,{
      width: '250px',
      data: addEditModel,
      disableClose: true
    });
    dialogRef.afterClosed().subscribe(
      next => {
        console.log(next);
        if(next instanceof Category){
          if(this.selectListCategories != null && this.selectListCategories.length > 0){
            const removeIndex: number = this.selectListCategories.findIndex(cat=>cat.name.toUpperCase() == next.name.toUpperCase());
            if(removeIndex > 0) {
              this.selectListCategories.splice(removeIndex,1);
            }            
          }
          this.submitMessage = 'Added Catergory';
          this.openMatSnackBar(this.submitMessage);
        } else if (next !== "No Action") {
          this.submitMessage = next;
          this.openMatSnackBar(this.submitMessage);
        }
      }
    );
  }


  editCategoryOpen(categoryID){
    console.log(categoryID);
    const addEditModel = new AddEditModel(this.authenticationService.getUserId(), this.note.id, categoryID,false);
    const dialogRef = this.matDialog.open(CategoryComponent,{
      width: '250px',
      data: addEditModel,
      disableClose: true
    });
    dialogRef.afterClosed().subscribe(
      next => {
        if( next !== "No Action" ){
          this.submitMessage = next;
          this.openMatSnackBar(this.submitMessage);
        }        
      }
    );
  }

  async deleteCategory(categoryID){
    let result;
    await this.categoryService.deleteCategory(this.note.id,categoryID).then(
      res => result = res,
      err => result = err
    );
    if(result){
      this.submitMessage = "Category deleted";
      this.openMatSnackBar(this.submitMessage);
    } else {
      this.submitMessage = "Category deletion failed";
      this.openMatSnackBar(this.submitMessage);
    }
  }

  async deleteNote(){
    this.btnEnable = false;
    let result;
    await this.notesService.deleteNote(this.noteID).then(
      res => result = res,
      err => result = err
    );
    if(result){
      this.submitMessage = "Note deleted";
      this.deleteReminder(this.noteID,this.note.reminders);
      this.openMatSnackBar(this.submitMessage);
      this.routerService.routeToDashboard();
    } else {
      this.submitMessage = "Note deletion failed";
      this.openMatSnackBar(this.submitMessage);
    }
    this.btnEnable = true;
  }

  deleteReminder(noteID: Number, reminderArray: Array<NoteReminder>){
    if(reminderArray!=null && reminderArray.length > 0){
      reminderArray.forEach( rem => {
        this.reminderService.deleteReminder(rem.name, noteID);
      });
    }
  }


  addReminderOpen(){
    const dialogRef = this.matDialog.open(ReminderComponent,{
      width: '250px',
      data: { 
              'userID' : this.authenticationService.getUserId(),
              'note' : this.note,
              'reminder' : null,
              'isNew' : true
            },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe(
      next => {
        console.log(next);
        if(next instanceof NoteReminder){
          this.submitMessage = 'Added Reminder';
          this.openMatSnackBar(this.submitMessage);
        } else if(next !== "No Action"){
          this.submitMessage = next;
          this.openMatSnackBar(this.submitMessage);
        }
      }
    );
  }

  editReminderOpen(reminder: NoteReminder){
    const dialogRef = this.matDialog.open(ReminderComponent,{
      width: '250px',
      data: { 
              'userID' : this.authenticationService.getUserId(),
              'note' : this.note,
              'reminder' : reminder,
              'isNew' : false
            },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe(
      next => {
        console.log(next);
        if(next && next instanceof NoteReminder){
          this.submitMessage = 'Edited Reminder';
          this.openMatSnackBar(this.submitMessage);
        } else if(next !== "No Action"){
          this.submitMessage = next;
          this.openMatSnackBar(this.submitMessage);
        }
      }
    );
  }

  addReminderForNewNote(noteID: Number, noteName: string,reminderArray: NoteReminder[]){
    if(reminderArray != null && reminderArray.length > 0){
      reminderArray.forEach(r => {
        this.reminderService.addReminder(r,noteID,noteName);
      });
    }
  }

  openMatSnackBar(message: string) {
    let matSnackBarConfig : MatSnackBarConfig = new MatSnackBarConfig();
    matSnackBarConfig.verticalPosition = 'bottom';
    this.matSnackBar.open(message,'OK',matSnackBarConfig)._dismissAfter(3000);
  }

}
