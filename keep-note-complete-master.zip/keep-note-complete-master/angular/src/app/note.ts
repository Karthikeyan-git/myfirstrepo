import { NoteReminder } from './noteReminder';
import { Category } from './category';

export class Note {
  id: Number;
  title: string;
  text: string;
  reminders: Array<NoteReminder>;
  categories: Array<Category>;

  constructor() {
    this.title = '';
    this.text = '';
    this.reminders = new Array<NoteReminder>();
    this.categories = new Array<Category>();
  }
}
