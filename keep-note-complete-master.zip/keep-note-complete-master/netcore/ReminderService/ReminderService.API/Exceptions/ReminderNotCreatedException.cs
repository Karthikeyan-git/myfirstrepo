﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReminderService.API.Exceptions
{
    public class ReminderNotCreatedException:ApplicationException
    {

        public ReminderNotCreatedException() : base() { }

        public ReminderNotCreatedException(string message) : base(message) { }

    }
}
