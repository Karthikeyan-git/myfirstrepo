﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CategoryService.API.Models
{
    public class CategoryUser
    {
        [BsonId]
        public string UserId { get; set; }

        public List<Category> Categories { get; set; }
    }
}
