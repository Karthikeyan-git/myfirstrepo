import { Note } from "./note";

export class noteuser{
    userid: string;
    notes: Array<Note>;

    constructor(userID: string){
        this.userid = userID;
        this.notes = new Array<Note>();
    }
}