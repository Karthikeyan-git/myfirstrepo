﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NoteService.API.Models;

namespace NoteService.API.Service
{
    public interface INoteService
    {
        Note CreateNote(NoteUser noteUser);
        Note AddNote(string userId, Note note);
        bool DeleteNote(string userId, int noteId);
        Note UpdateNote(int noteId, string userId, Note note);
        List<Note> GetAllNotes(string userId);
        Note GetNote(string userId, int noteId);
        List<Note> GetNotes(string userId, string categoryName);

        List<Category> GetAllCategories(string userId);
        List<Category> GetAllCategories(string userId, int noteId);
        bool DeleteCategory(string userId, int noteId, int categoryId);
        Category AddCategory(string userId, int noteId, Category category);
        Category EditCategory(string userId, int noteId, int categoryId, Category category);

        List<Category> GetDistinctCategories(string userId);
        List<Category> GetDistinctCategories(string userId, int noteId);

        bool DeleteReminder(string userId, int noteId, int reminderId);
        Reminder AddReminder(string userId, int noteId, Reminder reminder);
        Reminder EditReminder(string userId, int noteId, int reminderId, Reminder reminder);
    }
}
