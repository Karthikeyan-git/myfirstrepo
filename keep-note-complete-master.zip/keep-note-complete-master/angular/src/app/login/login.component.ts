import { Component, ViewChild, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormGroupDirective, FormBuilder } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';
import { HttpErrorResponse } from '@angular/common/http';
import { UserInfo } from '../userInfo';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    userId = new FormControl('');
    password = new FormControl('');
    loginForm: FormGroup;
    submitMessage: string;
    @ViewChild(FormGroupDirective) loginFormDirective;

    constructor(private formBuilder: FormBuilder, private authenticationService: AuthenticationService,
      private routerService: RouterService) { }

    ngOnInit() {
      this.userId.setValidators([Validators.minLength(5), Validators.required]);
      this.password.setValidators(Validators.required);
      this.loginForm = this.formBuilder.group({
        'userId': this.userId,
        'password': this.password
        });
    }

    async loginSubmit() {
      let result: Boolean = false;
      let user: User;
      user= new User(this.userId.value,'','',this.password.value);
      await this.authenticationService.loginUser(user).then(
         res => {
          result=res;
          console.log('promise : '+res);
         }
      ).catch( err => {
        result = false;
      });
      console.log(result);
      if(result){
        this.routerService.routeToDashboard();
      } else {
        this.submitMessage = 'Check UserID and password';
        //this.routerService.routeToLogin();
      }
      this.loginFormDirective.reset();
    }

    register(){
      this.routerService.routeToRegister();
    }
}
