import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest,
     HttpEvent, HttpErrorResponse, HttpHandler } from '@angular/common/http';
import { RouterService } from './services/router.service';
import { catchError, map} from 'rxjs/operators';
import { Observable } from 'rxjs';


@Injectable()
export class AuthHttpInterceptor implements HttpInterceptor {

    constructor(private routerService: RouterService){}

    intercept(req: HttpRequest<any>, next: HttpHandler):Observable<HttpEvent<any>>{
        return next.handle(req).pipe(
            catchError((error: HttpErrorResponse) => {
                console.log(error);
                if(error.status === 401){
                    this.routerService.routeToLogin();
                } 
                return next.handle(req);
            })
        );
    }
}

