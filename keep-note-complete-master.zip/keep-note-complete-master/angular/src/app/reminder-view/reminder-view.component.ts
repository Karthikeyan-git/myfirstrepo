import { Component, OnInit } from '@angular/core';
import { ReminderService } from '../services/reminder.service';
import { RouterService } from '../services/router.service';
import { ActivatedRoute } from '@angular/router';
import { Reminder } from '../reminder'; 

@Component({
  selector: 'app-reminder-view',
  templateUrl: './reminder-view.component.html',
  styleUrls: ['./reminder-view.component.css']
})
export class ReminderViewComponent implements OnInit {

  private reminders: Array<Reminder>;
  private isViewReady: boolean = false;
  private isGridView: boolean = true;
  private dispStyle: string = 'keep-reminders-grid';

  constructor(private reminderService: ReminderService, private activatedRoute: ActivatedRoute, private routerService: RouterService) { }

  ngOnInit() {
    this.isViewReady = false;
    this.activatedRoute.params.subscribe(
      next => {
        this.getReminders();
      }, err => {
        this.reminders = new Array<Reminder>();
      }
    )    
    this.isViewReady = true;
  }

  getReminders(){
    this.reminderService.getAllReminders().subscribe(
      next => this.reminders = next,
      err => this.reminders = new Array<Reminder>()
    );
  }

  routeToNoteEdit(noteId: Number){
    this.routerService.routeToEditNoteView(noteId);
  }

  switchView(){
    this.isGridView = !this.isGridView;
    if(this.isGridView){
      this.dispStyle = 'keep-reminders-grid';
    } else {
      this.dispStyle = 'keep-reminders-list';
    }
  }


}
