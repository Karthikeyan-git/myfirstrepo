﻿using AuthenticationService.Configurations;
using AuthenticationService.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace AuthenticationService.Extensions
{
    public class JwtAuth : ActionFilterAttribute
    {
        private  JWTConfiguration jWTConfiguration;
        public JwtAuth(IOptions<JWTConfiguration> jwtConfigOptions)
        {
            jWTConfiguration = jwtConfigOptions.Value;
        }

        private  string GenerateToken(User user)
        {
            byte[] key = Encoding.ASCII.GetBytes(jWTConfiguration.SecretKey);
            JwtSecurityTokenHandler jwtSecurityTokenHandler = new JwtSecurityTokenHandler();
            SecurityTokenDescriptor securityTokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.NameIdentifier,user.UserId)
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                Issuer = jWTConfiguration.Issuer,
                Audience = jWTConfiguration.Audience,
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            JwtSecurityToken token = jwtSecurityTokenHandler.CreateJwtSecurityToken(securityTokenDescriptor);
            return jwtSecurityTokenHandler.WriteToken(token);
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            if (context.Result is OkObjectResult)
            {
                OkObjectResult okr = (OkObjectResult)context.Result;
                context.Result = new OkObjectResult(new { token = GenerateToken((User)okr.Value) });
            }
        }
    }
}
