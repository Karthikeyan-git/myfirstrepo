import { Component, OnInit } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';
import { RouterService } from '../services/router.service';
import { ActivatedRoute } from '@angular/router';
import { CatRem } from '../catRem';

@Component({
  selector: 'app-list-view',
  templateUrl: './list-view.component.html',
  styleUrls: ['./list-view.component.css']
})
export class ListViewComponent implements OnInit {

  // notStartedNotes: Array<Note>;
  // startedNotes: Array<Note>;
  // completedNotes: Array<Note>;
  notes: Array<Note>;
  subHeading: string;
  remainder: boolean = false;
  isViewReady: boolean = false;

  constructor(private notesService: NotesService, private routerService: RouterService, private activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    this.activatedRoute.params.subscribe(
      next => {
        if(next != null && next.catRem != null) {
          let catRem = localStorage.getItem('catRem');
          if(catRem!=null) {
            let cr: CatRem = JSON.parse(catRem);
            if(cr.isCat){
              this.subHeading = `Notes with Category : ${cr.category.name}`;
              this.getNotesByCategory(cr.category);
            } else {
              this.subHeading = 'Notes with Reminder';
              this.getNotesWithReminders();
            }
          } else {
            this.subHeading=undefined;
            this.getNotes();
          }
        } else {
          this.subHeading=undefined;
          this.getNotes();
        }
        this.isViewReady = true;
      }, err => {
        this.subHeading=undefined;
        this.getNotes();
        this.isViewReady = true;
      }
    );    
  }

  getNotes(){
    this.notesService.getNotes().subscribe(
      next => {
        this.notes=next;
      },
      err => {
        if(err instanceof ErrorEvent){
          if(err.error.statuscode === 401){
            this.routerService.routeToLogin();
          }
        }
      }
    );
  }

  getNotesByCategory(category){
    this.getNotes();
    this.notes = this.notes.filter(nt => {
      if(nt.categories != null && nt.categories.some(cat => cat.name.toUpperCase() == category.name.toUpperCase())){
        return nt;
      }
    });
    console.log(this.notes);
    // this.notesService.getNotesByCategory(category).subscribe(
    //   next => {
    //     this.notes=next;
    //   },
    //   err => {
    //     if(err instanceof ErrorEvent){
    //       if(err.error.statuscode === 401){
    //         this.routerService.routeToLogin();
    //       }
    //     }
    //   }
    // );
  }
  
  getNotesWithReminders(){
    this.getNotes();
    this.notes = this.notes.filter(nt => nt.reminders != null && nt.reminders.length > 0);
    // this.notesService.getNotesWithRemainder().subscribe(
    //   next => {
    //     this.notes=next;
    //   },
    //   err => {
    //     if(err instanceof ErrorEvent){
    //       if(err.error.statuscode === 401){
    //         this.routerService.routeToLogin();
    //       }
    //     }
    //   }
    // );
  }
}
