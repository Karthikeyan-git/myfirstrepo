﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ReminderService.API.Models;

namespace ReminderService.API.Service
{
    public interface IReminderService
    {
        ReminderUser CreateReminder(ReminderUser reminderUser);
        Reminder AddReminder(string userId, Reminder reminder);
        bool DeleteReminder(string userId, int noteId, string reminderName);
        Reminder UpdateReminder(string userId, int noteId, string reminderName, Reminder reminder);
        ReminderUser GetReminderUserById(string userId);
        Reminder GetReminderById(string userId, int noteId, string reminderName);
        List<Reminder> GetAllReminders(string userId);
    }
}
