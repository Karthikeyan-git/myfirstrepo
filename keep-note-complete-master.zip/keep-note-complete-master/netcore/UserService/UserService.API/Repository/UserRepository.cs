﻿using System.Linq;
using MongoDB.Bson;
using MongoDB.Driver;
using UserService.API.Models;

namespace UserService.API.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly IUserContext userContext;

        public UserRepository(IUserContext userContext)
        {
            this.userContext = userContext;
        }

        public bool DeleteUser(string userId)
        {
            DeleteResult dr = userContext.Users.DeleteOne<User>(u => u.UserId == userId);
            return dr.IsAcknowledged && dr.DeletedCount > 0;
        }

        public User GetUserById(string userId)
        {
            User user = userContext.Users.Find(u => u.UserId == userId).FirstOrDefault();
            return user;
        }

        public User RegisterUser(User user)
        {
            userContext.Users.InsertOne(user);
            return GetUserById(user.UserId);
        }

        public bool UpdateUser(string userId, User user)
        {
            BsonDocumentUpdateDefinition<User> bsonDocumentUpdateDefinition = new BsonDocumentUpdateDefinition<User>(new BsonDocument{ { "$set", user.ToBsonDocument() } });
            UpdateResult ur = userContext.Users.UpdateOne<User>(u => u.UserId == userId, bsonDocumentUpdateDefinition);
            return ur.IsAcknowledged && ur.ModifiedCount > 0;
        }
    }
}
