﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserService.API.Configurations
{
    public class MongoDBConfiguration
    {
        public String ConnectionString { get; set; }
 
        public String Database { get; set; }
    }
}
