import { Category } from './category';

export class CatRem{
    isCat: boolean;
    category: Category;

    constructor(isCat: boolean, catName: Category){
        this.isCat = isCat;
        this.category = catName;
    }
}