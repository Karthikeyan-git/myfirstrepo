﻿using AuthenticationService.Exceptions;
using AuthenticationService.Filters;
using AuthenticationService.Models;
using AuthenticationService.Service;
using Microsoft.AspNetCore.Mvc;
using System;
using AuthenticationService.Extensions;
using AuthenticationService.JWT;
using System.Text;

namespace AuthenticationService.Controllers
{
    [Route("auth")]
    [ExceptionLogger]
    //[TypeFilter(typeof(LoggingAspect))]
    public class AuthController : Controller
    {
        private readonly IAuthService service;
        private readonly IJWTAuthValidation jWTAuthValidation;

        public AuthController(IAuthService _service, IJWTAuthValidation _jWTAuthValidation )
        {
            service = _service;
            jWTAuthValidation = _jWTAuthValidation;
        }

        // POST api/<controller>
        [HttpPost]
        [Route("register")]
        public IActionResult Register([FromBody]User user)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    user.AddedDate = DateTime.Now;
                    bool r = service.RegisterUser(user);
                    if (r)
                    {
                        string _token = jWTAuthValidation.GenerateToken(user);
                        log("token", _token);
                        return new JsonResult(new { token = _token });
                    } else
                    {
                        log("Registeration failed");
                        return new JsonResult(new { token = "" });
                    }
                }
                catch(UserNotCreatedException ex)
                {
                    log("Exception", ex.ToString());
                    return new JsonResult(new { token = "" });
                }
            }
            else
            {
                throw new ModelInvalidException(typeof(User).Name);
            }
        }
        
        [HttpPost]
        [Route("login")]
        //[TypeFilter(typeof(JwtAuth))]  //uncomment to get JWT token
        public IActionResult Login([FromBody]User user)
        {
            log(user.UserId);
            try
            {
                User _user = service.LoginUser(user.UserId, user.Password);
                string _token=jWTAuthValidation.GenerateToken(_user);
                log("token", _token);
                return new JsonResult(new { token = _token });
            }
            catch (UserNotFoundException ex)
            {
                log("Exception", ex.ToString());
                return new JsonResult(new { token = "" });
            }
        }

        [HttpGet]
        [Route("validate")]
        public IActionResult Validate([FromHeader]string Authorization)
        {
            log("Validate : reached");
            log(Authorization);
            bool isValid = jWTAuthValidation.ValidateToken(Authorization);
            return Ok(isValid);
        }

        private static void log(params string[] messages)
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("Authentication Controller :");
            foreach(var msg in  messages){
                stringBuilder.Append(" ; ");
                stringBuilder.Append(msg);                
            }
            Console.WriteLine(stringBuilder.ToString());
        }

    }
}
