import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserInfo } from '../userInfo';
import { tokenKey } from '@angular/core/src/view';
import { User } from '../user';

@Injectable()
export class AuthenticationService {

  private loginURL: string;
  private registerURL: string;
  private validateURL: string;
  private isLogged: Boolean = false;
  private userAPIPostURL: string;

  constructor(private httpClient: HttpClient) {
    this.loginURL  = 'http://localhost:8000/auth/login';
    this.registerURL = 'http://localhost:8000/auth/register';
    this.validateURL = 'http://localhost:8000/auth/validate';
    this.userAPIPostURL = 'http://localhost:8002/api/user';
  }

  async loginUser(data: User): Promise<Boolean> {
    console.log(data);
    let token;
    let result;
    token = await this.httpClient.post(this.loginURL, data).toPromise();
    console.log(token);
    if(token != null && token.token !== null && token.token !== ''){
      const userInfo: UserInfo = new UserInfo(data.userId, token.token);
      this.setUserInfo(userInfo);
      result = true;
    } else {
      result = false;
    }    
    let loginResult = new Promise<Boolean>((res) => {
      res(result);
    });
    return loginResult;
  }

  setUserInfo(userInfo: UserInfo) {
    this.isLogged=true;
    localStorage.setItem('userInfo',JSON.stringify(userInfo));
  }

  clearUserInfo() {
    this.isLogged=false;
    if (localStorage.getItem('catRem') !=null ) {
      localStorage.removeItem('catRem');
    }    
    localStorage.removeItem('userInfo');
    sessionStorage.clear();
  }

  getBearerToken() {
    const userInfo: UserInfo = JSON.parse(localStorage.getItem('userInfo'));
    if(userInfo){
      return userInfo.token;
    }
    return "";
  }

  getUserId(){
    const userInfo: UserInfo = JSON.parse(localStorage.getItem('userInfo'));
    if(userInfo){
      return userInfo.userId;
    }
    return "";
  }

  getIsAuthenticated() : Boolean{
    let userInfo = localStorage.getItem('userInfo');
    if(userInfo != null){
      this.isLogged = true;
    }
    return this.isLogged;
  }

  async registerUser(data: User): Promise<boolean> {
    let result;
    let r=false;
    await this.httpClient.post(this.registerURL, data).toPromise().then(
      next => {
        result = next;
      },
      err => {
        result = err;
      }
    );
    if(result!=null && result.token != ""){
      this.setUserInfo(new UserInfo(data.userId,result.token));
      this.httpClient.post(this.userAPIPostURL,data,
        {
          headers: new HttpHeaders().set('Authorization', `Bearer ${result.token}`)
        });
      r=true;
    } else {
      r=false;
    }

    return new Promise<boolean>((res,rej) => {
      if (r === true) {
        res(true);
      } else {
        rej (result);
      }
    });
  }

  async isUserAuthenticated(token): Promise<boolean> {
    console.log('isUserAuthenticated started: '+ token); 
    let isAuth;
    isAuth = await this.httpClient.get<boolean>(this.validateURL,
          {
            headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
          }).toPromise();
         
    const authResult = new Promise<boolean>((res) => {
      res(isAuth);
    });
    console.log('isUserAuthenticated ended: ');
    return authResult;
  }
}
