﻿using ReminderService.API.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReminderService.API.Extensions
{
    public class ExceptionLoggerAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            var exception = context.Exception;
            if (exception is ReminderNotFoundException)
            {
                context.Result = new NotFoundResult();
            }
            else if (exception is ReminderNotCreatedException)
            {
                context.Result = new ConflictResult();
            }
            else if (exception is ModelInvalidException)
            {
                //BadRequestObjectResult - status code is 400 by default
                context.Result = new BadRequestObjectResult(exception.Message);
            }
            else
            {
                context.HttpContext.Response.StatusCode = 500;
                context.Result = new JsonResult("Internal server error");
            }
        }
    }
}
