import { Injectable, OnInit } from '@angular/core';
import { Note } from '../note';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { tap } from 'rxjs/operators';
import { NoteReminder } from '../noteReminder';

@Injectable()
export class NotesService implements OnInit {

  notes: Array<Note>;
  notesSubject: BehaviorSubject<Array<Note>>;
  notesURL: string;
  getNotesByCategoryURL: string;
  getNotesWithReminderURL: string;
  addReminderURL: string;
  editReminderURL: string;
  deleteReminderURL: string;
  reminders: Array<NoteReminder>;
  reminderSubject: BehaviorSubject<Array<NoteReminder>>;

  constructor(private httpClient: HttpClient, private authenticationService: AuthenticationService) {
    this.notesURL = 'http://localhost:8001/api/notes/'+this.authenticationService.getUserId();
    this.getNotesByCategoryURL = 'http://localhost:8001/api/notes/getNotesByCategory/' + this.authenticationService.getUserId();
    this.getNotesWithReminderURL = this.notesURL + '/' + true;
    this.addReminderURL = 'http://localhost:8001/api/notes/addReminder/'+this.authenticationService.getUserId();
    this.editReminderURL = 'http://localhost:8001/api/notes/editReminder/'+this.authenticationService.getUserId();
    this.deleteReminderURL = 'http://localhost:8001/api/notes/deleteReminder/'+this.authenticationService.getUserId();
    this.notes = new Array<Note>();
    this.notesSubject = new BehaviorSubject<Array<Note>>(this.notes);
    this.reminders = new Array<NoteReminder>();
    this.reminderSubject = new BehaviorSubject<Array<NoteReminder>>(this.reminders);
    this.fetchNotesFromServer();
  }

  ngOnInit(){
    
  }

  fetchNotesFromServer() {
    this.httpClient.get<Note[]>(this.notesURL, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).subscribe(
      next => {
        this.notes = next;
        this.notesSubject.next(this.notes);
      },
      err => {
        console.log(err);
        this.notes = new Array<Note>();
        this.notesSubject.next(this.notes);
      }
    );
  }

  getNotes(): BehaviorSubject<Array<Note>> {
    return this.notesSubject;
  }

  getNotesArray(): Array<Note> {
    return this.notes;
  }

  getNotesByCategory(category): BehaviorSubject<Array<Note>> {
    this.httpClient.post<Array<Note>>(this.getNotesByCategoryURL,category,{
        headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`),
    }      
    ).subscribe(
      next=>{
        this.notes=next;
        this.notesSubject.next(this.notes);
      },
      err => {
        console.log(err);
        this.notes = new Array<Note>();
        this.notesSubject.next(this.notes);
      }
    );
    return this.notesSubject;
  }

  getNotesWithRemainder(): BehaviorSubject<Array<Note>>{
    this.httpClient.get<Array<Note>>(this.getNotesWithReminderURL,{
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).subscribe(
      next=>{
        this.notes=next;
        this.notesSubject.next(this.notes);
      },
      err => {
        console.log(err);
        this.notes = new Array<Note>();
        this.notesSubject.next(this.notes);
      }
    );
    return this.notesSubject;
  }

  async addNote(note: Note): Promise<Note> {
    let isAdd: Boolean = false;
    let newNote: Note;
    await this.httpClient.post<Note>(this.notesURL, note,
    {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).pipe(
      tap(addedNote => {
        newNote = addedNote;
        console.log(addedNote);
        isAdd = true;
        this.notes.push(addedNote);
        this.notesSubject.next(this.notes);
      })
    ).toPromise();
    const result: Promise<Note> = new Promise<Note>((res,rej)=>{
      if(isAdd){
        res(newNote);
      } else {
        rej(false);
      }
    });
    return result;
  }

  async editNote(note: Note): Promise<Boolean> {
    let isEdit: Boolean = false;
    const putURL = this.notesURL.concat('/', note.id.toString());
    console.log(putURL);

    await this.httpClient.put<Note>(putURL, note,
    {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).pipe(
      tap(updatedNote => {
        console.log(updatedNote);
        const arrNote: Note = this.getNoteById(updatedNote.id);
        Object.assign(arrNote, updatedNote);
        isEdit = true;
        this.notesSubject.next(this.notes);
      })
    ).toPromise();

    const editResult: Promise<Boolean> = new Promise<Boolean> ((res,rej) => {
      if(isEdit){
        res(true);
      } else {
        rej(false);
      }
    });

    return editResult;
  }

  async deleteNote(noteId: Number){
    let result: boolean;
    await this.httpClient.delete(this.notesURL + '/' + noteId,
    {
        headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).toPromise().then( 
      success => {
        if(success == true){
          result=true;
        } else {
          result = false;
        }
      },
      err => {
        result = false;
      }
    )
    const resultPromise: Promise<boolean> = new Promise<boolean>((res,rej) => {
      if(result){
        this.notes.splice(this.notes.findIndex(nt => nt.id == noteId),1);
        this.notesSubject.next(this.notes);
        res(true);
      } else {
        rej(false);
      }
    });

    return resultPromise;
  }

  getNoteById(noteId): Note {
    const ntID: Number = Number.parseInt(noteId);
    console.log(this.notes);
    return this.notes.find(n => n.id == ntID);
  }


  //reminder methods

  setReminders(remArray: NoteReminder[]){
    this.reminders = remArray;
    this.reminderSubject.next(this.reminders);
  }

  getReminders() : BehaviorSubject<Array<NoteReminder>>{
    return this.reminderSubject;
  }

  async addReminderToList(noteReminder: NoteReminder) : Promise<NoteReminder>{
    this.reminders.push(noteReminder);
    this.reminderSubject.next(this.reminders);
    return new Promise<NoteReminder>((res,rej) => {
      res(noteReminder);
    });
  }
  

  async addReminder(noteId: Number, noteReminder: NoteReminder): Promise<NoteReminder>{
    const addedReminder = await this.httpClient.post<NoteReminder>(this.addReminderURL + '/' + noteId, noteReminder,
    {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).toPromise();
    console.log(addedReminder);
    const result: Promise<NoteReminder> = new Promise<NoteReminder>((res,rej) => {
      if(addedReminder && addedReminder != null){
        this.reminders.push(addedReminder);
        this.reminderSubject.next(this.reminders);
        res(addedReminder);
      } else {
        rej(false);
      }
    });
    return result;
  }

  async editReminder(noteId: Number, reminderId: Number, noteReminder: NoteReminder): Promise<boolean>{
    const updatedReminder = await this.httpClient.put<NoteReminder>(this.editReminderURL + '/' + noteId + '/' + reminderId, noteReminder,
    {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).toPromise();
    console.log(updatedReminder);
    const result: Promise<boolean> = new Promise<boolean>((res,rej) => {
      if(updatedReminder && updatedReminder != null){
        let remIndex: number = this.reminders.findIndex(rem => rem.id === reminderId);
        this.reminders.splice(remIndex,1,noteReminder);
        this.reminderSubject.next(this.reminders);
        res(true);
      } else {
        rej(false);
      }
    });
    return result;
  }

  async deleteReminder(noteId: Number, reminderId: Number): Promise<boolean>{
    const deleteResult: boolean = await this.httpClient.delete<boolean>(this.deleteReminderURL + '/' + noteId + '/' + reminderId,
    {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authenticationService.getBearerToken()}`)
    }).toPromise();
    console.log(deleteResult);
    const result: Promise<boolean> = new Promise<boolean>((res,rej) => {
      if(deleteResult && deleteResult != null && deleteResult === true){
        let remIndex: number = this.reminders.findIndex(rem => rem.id === reminderId);
        this.reminders.splice(remIndex,1);
        res(true);
      } else {
        rej(false);
      }
    });
    return result;
  }
  
}
