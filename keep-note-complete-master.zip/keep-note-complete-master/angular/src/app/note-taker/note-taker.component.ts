import { Component, OnInit, ViewChild } from '@angular/core';
import {NotesService} from '../services/notes.service';
import {HttpClient} from '@angular/common/http';
import { NoteEditorComponent } from '../note-editor/note-editor.component';

@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css']
})
export class NoteTakerComponent implements OnInit {

  private panelExpand = true;
  private errMessage: string;

  constructor(private notesService: NotesService, private httpClient: HttpClient) {

  }

  ngOnInit() {
  }

  togglePanel() {
    this.panelExpand = !this.panelExpand;
  }

}
