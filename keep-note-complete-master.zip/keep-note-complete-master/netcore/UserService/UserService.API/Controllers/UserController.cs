﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using UserService.API.Exceptions;
using UserService.API.Extensions;
using UserService.API.Models;
using UserService.API.Service;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace UserService.API.Controllers
{
    [Route("api/[controller]")]
    [ExceptionLogger]
    [TypeFilter(typeof(LoggingAspect))]
    [Authorize]
    public class UserController : Controller
    {
        private IUserService userService;

        public UserController(IUserService _userService)
        {
            userService = _userService;
        }


        // GET: api/<controller>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            return Ok(userService.GetUserById(id));
        }

        // POST api/<controller>
        [HttpPost]
        public IActionResult Post([FromBody]User user)
        {
            if (ModelState.IsValid)
            {
                return Created($"api/User/", userService.RegisterUser(user));
            }
            else
            {
                throw new ModelInvalidException(typeof(User).Name);
            }
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public IActionResult Put(string id, [FromBody]User user)
        {
            if (ModelState.IsValid)
            {
                userService.UpdateUser(id, user);
                return Ok(userService.GetUserById(user.UserId));
            }
            else
            {
                throw new ModelInvalidException(typeof(User).Name);
            }
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            return Ok(userService.DeleteUser(id));
        }
    }
}
