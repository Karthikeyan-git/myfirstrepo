﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Driver;
using Microsoft.Extensions.Configuration;

namespace AuthenticationService.Models
{
    public class AuthenticationMongoContext : IAuthenticationMongoContext
    {
        readonly IMongoDatabase db;

        public AuthenticationMongoContext(IConfiguration configuration)
        {
            IMongoClient mongoClient = new MongoClient(configuration.GetSection("MongoConfiguration:ConnectionString").Value);
            db = mongoClient.GetDatabase(configuration.GetSection("MongoConfiguration:Database").Value);
        }
        public IMongoCollection<User> users { get => db.GetCollection<User>("Users"); }
    }
}
