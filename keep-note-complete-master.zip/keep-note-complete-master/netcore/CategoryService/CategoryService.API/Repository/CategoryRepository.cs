﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CategoryService.API.Models;
using MongoDB.Bson;
using MongoDB.Driver;

namespace CategoryService.API.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly ICategoryContext categoryContext;

        public CategoryRepository(ICategoryContext _categoryContext)
        {
            categoryContext = _categoryContext;
        }

        public CategoryUser CreateCategory(CategoryUser categoryUser)
        {
            categoryContext.CategoryUsers.InsertOne(categoryUser);
            return GetCategoryUserById(categoryUser.UserId);
        }

        public bool AddCategory(string userId, Category category)
        {
            CategoryUser cu = GetCategoryUserById(userId);
            if(cu.Categories != null && cu.Categories.Count > 0)
            {
                category.Id = cu.Categories.Max<Category>(cat => cat.Id) + 1;
            }
            else
            {
                cu.Categories = new List<Category>();
                category.Id = 1;
            }
            var updateDef = Builders<CategoryUser>.Update.Push<Category>(catUser => catUser.Categories, category);
            UpdateResult ur = categoryContext.CategoryUsers.UpdateOne(catUser => catUser.UserId == userId, updateDef);
            return ur.IsAcknowledged && ur.ModifiedCount > 0;
        }
        public bool DeleteCategory(string userId,string categoryName)
        {
            var updateCatUserDef = Builders<CategoryUser>.Update.PullFilter<Category>(cu => cu.Categories, cat => cat.Name.ToUpper()==categoryName.ToUpper());
            UpdateResult ur = categoryContext.CategoryUsers.UpdateOne<CategoryUser>(cu => cu.UserId == userId, updateCatUserDef);
            return ur.IsAcknowledged && ur.ModifiedCount > 0;
        }

        public List<Category> GetAllCategoriesByUserId(string userId)
        {
            return categoryContext.CategoryUsers.Find<CategoryUser>(c => c.UserId == userId).FirstOrDefault().Categories;
        }

        public CategoryUser GetCategoryUserById(string userId)
        {
            return categoryContext.CategoryUsers.Find(c => c.UserId == userId).FirstOrDefault();
        }

        public bool UpdateCategory(string userId,string categoryName, Category category)
        {
            //BsonDocumentUpdateDefinition<CategoryUser> bsonDocumentUpdateDefinition = new BsonDocumentUpdateDefinition<CategoryUser>(new BsonDocument { { "Categories.$", category.ToBsonDocument() } });
            var updateDef = Builders<CategoryUser>.Update.Set("Categories.$", category);
            UpdateResult updateResult = categoryContext.CategoryUsers.UpdateOne(cu => cu.UserId == userId && cu.Categories.Any(cat => cat.Name.ToUpper() == categoryName.ToUpper()), updateDef);
            return updateResult.IsAcknowledged && updateResult.ModifiedCount > 0; 
        }
    }
}
